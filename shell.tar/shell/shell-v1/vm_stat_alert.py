#!/usr/bin/python
# -*- coding:utf-8 -*-
#
# Author : Xufu huang
# Email  : hxfn1692@corp.netease.com
# Date   : 2015年10月12日 星期一 17时10分
# Desc   : This script is used for monitor vm status by using 'virsh list'.
#          if got vm not running, then gpost to blackhole.
# Usage  : python vm_stat_alert.py
# Note   : this script often run in a crontab
#
# Update : 1. if vm just build and not start, then ignore this vm
# Update : 2. get vm  project name from 'virsh dumxml'.@chenqiyi-20181129

import subprocess
import shlex
import logging
import datetime
import os
import gpost
from logging import FileHandler

VM_LOG_PREFIX = "/var/log/libvirt/qemu/"
LOGFILE = "/home/cld/log/vm_stat_alert.log"
LOG = logging.getLogger(os.path.abspath(__file__))
HANDLER = FileHandler(LOGFILE)
FMTER = logging.Formatter("%(asctime)s %(name)s [%(levelname)s]: %(message)s",\
                         "%Y-%m-%d %H:%M:%S")
HANDLER.setFormatter(FMTER)
LOG.addHandler(HANDLER)
LOG.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
handler.setLevel(logging.INFO)
handler.setFormatter(FMTER)
LOG.addHandler(handler)

def get_vm_stat():
    """
    get vm status by 'virsh list --all' and return a list of all status of VMs
    """
    cmd = "/usr/bin/virsh list --all"
    args = shlex.split(cmd)
    pro = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = pro.communicate()
    if pro.returncode != 0:
        e = Exception("cmd: %s error. %s" % (cmd, str(err)))
        LOG.exception(e)
        raise e
    ret = []
    for line in out.split('\n'):
        item = line.split()
        if len(item) > 2 and not item[0].startswith('Id'):
            one = [item[0], item[1], " ".join(item[2:])]
            ret.append(one)
    return ret

def get_vm_project(instance_name):
    """
    get vm project name by  'virsh dumpxml'
    """
    cmd = "virsh dumpxml %s |  grep nova:project | awk -F\">\" '{print $2}' | awk -F\"<\" '{print $1}'" % instance_name
    args = cmd
    pro = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    out, err = pro.communicate()
    if not out:
        out = "not found"
    return out.strip()

def get_alert_vm(status):
    """
    from vm status list, then get the not running list
    """
    alert_vm = []
    for l in status:
        if l[2] != "running":
            vm_log = VM_LOG_PREFIX + l[1] + ".log"
            if os.path.isfile(vm_log):
                preject_name = get_vm_project(l[1])
                l.append(preject_name)
                alert_vm.append(l)
                LOG.warning("Project %s VM %s is %s" %(l[3], l[1], l[2]))
            else:
                LOG.warning("VM %s is %s,it is just defined, skip it"\
                        %(l[1], l[2]))
        else:
            LOG.info("VM %s is %s" %(l[1], l[2]))
    return alert_vm

def alert(alert_vm):
    data = {"type" : "vm_alert"}
    alert_vm_list = []
    for i in alert_vm:
        data[i[1]] = {"project" : i[3], "state" : i[2]}
        string = "VM: %-25sProject: %s" %(i[1], i[3])
        alert_vm_list.append(string)
    msg = "%s" % "\n".join(alert_vm_list)
    try:
        gpost.blackhole(data=data, msg=msg)
        return True
    except Exception, e:
        LOG.exception(e)
        return False


def main():
    status = get_vm_stat()
    alert_vm = get_alert_vm(status)
    if len(alert_vm) > 0:
        alert(alert_vm)

if __name__ == "__main__":
    main()