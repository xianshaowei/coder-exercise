#!/bin/bash
 
# Comments to support chkconfig on Linux

 
# Author : xianwei
# Date   : 2019
# Tel: 13880675749

 
# ======================================
# Script for the xxx Server


# optimize   [] ---> [[]]

#set -o nounset
set -o errexit
#set -o verbose     #打印执行的代码
#set -o xtrace       #开启调试


logger()
{
    FGC_START="\E[1;"
    FGC_END="\E[00m"
    FGC_YELLOW="33m"
    FGC_RED="31m"
    FGC_GREEN="32m"
    FGC_WHITE="37m"
    local level=$1
    shift
    local msg="$@"

    local color=""
    local msg_datetime=$(date +"[%F %T]")

    case "$level" in
        [Ii][Nn][Ff][Oo]*)
            color=$FGC_WHITE
            ;;
        [Ww][Aa][Rr][Nn]*)
            color=$FGC_YELLOW
            ;;
        [Ee][Rr][Rr]*)
            color=$FGC_RED
            ;;
        *)
            color=$FGC_WHITE
            ;;
    esac

    echo -e $msg_datetime $level "${FGC_START}${color}$msg${FGC_END}" | tee -a $logfile 1>&2

#logger INFO ""echo green strings"
#logger WARRING ""echo yellow strings"
#logger ERROR "echo red strings"
}

logger ERROR "echo red strings"


