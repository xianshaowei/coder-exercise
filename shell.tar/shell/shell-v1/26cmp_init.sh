#!/bin/bash
 
# Comments to support 26 cmo-node to init env

 
# Author : xianwei
# Date   : 20190614
# Tel: 13880675749

 
# ======================================


set -o nounset
#set -o errexit      # 错误后立即退出，不再执行向后执行
#set -o verbose     # 打印执行的代码
#set -o xtrace      # 开启调试

ceph_conf="/etc/ceph/ceph.conf"
libvir_keyring_conf="/etc/ceph/libvirt.keyring"

cephfs_conf="/etc/ceph/cephfs.conf"
cephfs_keyring_conf="/etc/ceph/keyring.fs"

pool_list=("volans-site1-sas1200-img" "volans-site2-sas1200-img"
"volans-site3-sas1200-img" "volans-site4-sas1200-img"
"volans-site4-ssd960-img" "volans-site5-sata-img")


logfile="/tmp/cmp-init.log"




logger()
{
    logfile="/tmp/cmp-init.log"
    [[ ! -f "${logfile}}" ]] && touch "${logfile}"
    FGC_START="\033[1;"
    FGC_END="\033[0m"
    FGC_YELLOW="33m"
    FGC_RED="31m"
    FGC_GREEN="32m"
    FGC_WHITE="37m"
    local level=$1
    shift
    local msg="$@"

    local color=""
    local msg_datetime=$(date +"[%F %T]")

    case "$level" in
        [Ii][Nn][Ff][Oo]*)
            color=$FGC_GREEN
            ;;
        [Ww][Aa][Rr][Nn]*)
            color=$FGC_YELLOW
            ;;
        [Ee][Rr][Rr]*)
            color=$FGC_RED
            ;;
        *)
            color=$FGC_WHITE
            ;;
    esac
    echo -e $msg_datetime $level "${FGC_START}${color}$msg${FGC_END}" | tee -a $logfile 1>&2
}




check_role()
{

    if ! hostname |grep  -P 'cld-cmp\d+-26'
    then
       logger error "only support cmp-node for 26" && exit 1
    else
       logger info "check role is ok."
    fi

    if virsh list |grep running
    then
       logger error "Already have vm running, cannot execute the init scripte" && exit 1
    fi
}

init_kernel()
{
    uname -a |grep -w '3.16.56-1+deb8u1'
    if [ $? -ne 0 ];then
       logger warning "kernel is not 3.16.56-1+deb8u1,not to change kernel."
       logger info "apt-get install linux-image-3.16.0-6-amd64=3.16.56-1+deb8u1 -y --force-yes"
       apt-get install linux-image-3.16.0-6-amd64=3.16.56-1+deb8u1 -y --force-yes
    else
        logger info "kernel is 3.16.56-1+deb8u1,it's ok."
        return 0
    fi

    now_kernel_version=$(uname -a |awk '{print $3}')
    logger warning "pls, replace the kernel, do the following command:"
    logger info "apt-get purge linux-image-${now_kernel_version}"
    logger info "update-grub2"
    logger info "at last you need reboot to take effect！"

}

init_ceph()
{
    wget http://59.111.141.247:8080/26/ceph.conf -O ${ceph_conf}
    wget http://59.111.141.247:8080/26/libvirt.keyring -O ${libvir_keyring_conf}
    if [ `md5sum ${ceph_conf} |awk '{print $1}'` != 'c152dc9af77ece46a908f8e5054af8f3' ];then
        logger error "Error,${ceph_conf} is not correct!" && \
        exit 1
    fi
    if [ `md5sum ${libvir_keyring_conf} |awk '{print $1}'` != 'b2432fb37381af5774a3d6061876aa36' ];then
        logger error "Error,${libvir_keyring_conf} is not correct!" && \
        exit 1
     fi
    ceph --id libvirt df
    if [ $? -ne 0 ];then
       logger error "ceph init is fail.pls check." && exit 1
    fi
}


init_virshsecret()
{

    cat <<_EOF >virsh-secret.xml
<secret ephemeral='no' private='no'>
  <uuid>c204b55b-865c-4022-9d74-af3b2d20e4aa</uuid>
  <usage type='ceph'>
    <name>client.libvirt</name>
  </usage>
</secret>
_EOF
    logger info "virsh secret-define virsh-secret.xml"
    virsh secret-define virsh-secret.xml
    virsh secret-set-value c204b55b-865c-4022-9d74-af3b2d20e4aa --base64 'AQCdeKhVdsz/BxAAutgAmRVa9OiK/h68fV6vAA=='
    virsh secret-get-value c204b55b-865c-4022-9d74-af3b2d20e4aa
    if [ `virsh secret-get-value c204b55b-865c-4022-9d74-af3b2d20e4aa` != 'AQCdeKhVdsz/BxAAutgAmRVa9OiK/h68fV6vAA==' ];then
        logger error "virsh secret-get-value is error.pls check." && \
        exit 1
    fi
}


init_virshpool()
{

    if [[ $(virsh pool-list |grep -w active|wc -l) -ne 0 ]];then
        logger warn " virsh pool-destroy have been exist."
        return 0
    fi

    for poolname in "${pool_list[@]}"
    do
        echo ${poolname}
        cat <<_EOF >${poolname}.xml
<pool type='rbd'>
  <name>26-pool-name</name>
  <source>
    <host name='10.62.130.200' port='6789'/>
    <host name='10.62.130.201' port='6789'/>
    <host name='10.62.130.202' port='6789'/>
    <name>26-pool-name</name>
    <auth type='ceph' username='libvirt'>
      <secret uuid="c204b55b-865c-4022-9d74-af3b2d20e4aa"/>
    </auth>
  </source>
</pool>
_EOF
    sed -i "s/26-pool-name/${poolname}/g" ${poolname}.xml
    virsh pool-list --all |grep ${poolname}
    logger info "virsh pool-define ${poolname}.xml"
    virsh pool-define ${poolname}.xml
    [ $? -ne 0 ] && echo "virsh pool-define failed."  && continue
    logger info "virsh pool-start ${poolname}"
    virsh pool-start ${poolname}
    [ $? -ne 0 ] && echo "virsh pool-start failed."  && continue
    logger info "virsh pool-autostart ${poolname}"
    virsh pool-autostart ${poolname}
    [ $? -ne 0 ] && echo "virsh pool-autostart failed."  && continue

    done

}

init_cephfs()
{
    if [[ $(dpkg -l |grep -w ceph-fuse|wc -l) -eq 0 ]];then
        apt-get update
        apt-get install ceph-fuse
    fi

    cat <<_EOF > ${cephfs_conf}
[client.fs]
    client_mountpoint = /
    log file = /tmp/cephfs.log
    keyring = /etc/ceph/keyring.fs
    auth support = cephx none
    mon host = 10.62.130.200:6789;10.62.130.201:6789;10.62.130.202:6789
    client_quota = true
_EOF

    cat <<_EOF > ${cephfs_keyring_conf}
[client.fs]
    key = AQD7UthRwCM3MBAA+ys416c/EAqOMEaEvLz4CA==
_EOF

    if [ $(grep '/home/vm/cephfs/' /etc/fstab|wc -l) -eq 0 ];then
        echo "name=client.fs,conf=${cephfs_conf}  /home/vm/cephfs/  fuse.ceph rw,noatime,noauto 0 0" >>/etc/fstab
    fi

    if [ ! -f '/home/vm/cephfs' ];then
        mkdir -p /home/vm/cephfs
    fi

    if [ $(grep '/home/vm/cephfs/' /etc/rc.local|wc -l) -eq 0 ];then
        echo "mount /home/vm/cephfs/" >> /etc/rc.local
    fi

    if [[ $(df |grep cephfs|wc -l) -eq 0 ]];then
        mount /home/vm/cephfs/
    fi


    logger info "checking cephfs....."
    logger info "df |grep cephfs"
    df |grep cephfs
    logger info "cat /etc/rc.local |grep cephfs"
    cat /etc/rc.local |grep cephfs
}

init_buildkvm_env()
{
    cd /home/vm
    ln -sf cephfs/bin bin
    ln -sf cephfs/template template

    mkdir -p /home/vm/etc
    cd /home/vm/etc
    ln -sf ../cephfs/etc/build_kvm.volans.conf build_kvm.conf
    ln -sf ../cephfs/etc/build_kvm.loc.conf build_kvm.loc.conf
    echo "# Name  Network  IpAddr  PortGroup  Cpu  Mem(MB)  RbdType         Pool  DiskSize  Os      OsVer  Arch   AutoStart">/home/vm/cephfs/etc/volans/vmlist.`hostname -i`
    ln -sf /home/vm/cephfs/etc/volans/vmlist.`hostname -i` /home/vm/cephfs/etc/vmlist.`hostname -i`
    ln -sf /home/vm/cephfs/etc/vmlist.`hostname -i` /home/vm/etc/vmlist

    mkdir -p /home/vm/var/log
    mkdir -p /home/vm/var/lib/build_vm_flag

}


init_fwrule()
{
    logger info "init fwrule......"
    cat <<_EOF >/etc/fwrule/.fwrule.regdb
90 skeleton /usr/local/fwrule/skeleton/
50 ipset /home/cld/conf/fwrule/ipset/
50 svc /home/cld/conf/fwrule/svc/
50 skeleton /home/cld/conf/fwrule/skeleton/
40 skeleton /home/netmgr/var/fwrule/skeleton/
40 svc /home/netmgr/var/fwrule/svc/
_EOF
    [ ! -f "/etc/network/iptables" ] && touch /etc/network/iptables
    ln -sf /etc/network/iptables /etc/network/iptables.up.rules
    echo yes |config-fwrule.sh update && \
    genrules.sh update && \
    echo yes |iptables-apply

    iptables-save
}

init_interface()
{

    [ $(ovs-vsctl show |grep br0|wc -l) -ne 0 ] && echo "already set br0,exit." && return 0
    #[ $(grep 'br0' /etc/network/interfaces|wc -l) -ne 0 ] && echo "already set br0,exit." && return 0

    if [ $(ifconfig |grep bond0|wc -l) -ne 0 ];then
        master_ifac="bond0"
    else
        master_ifac="eth0"
    fi

    if [ $(ifconfig |grep bond1|wc -l) -ne 0 ];then
        second_ifac="bond1"
    else
        second_ifac="eth1"
    fi
    master_ip=$(hostname -i |grep -oP '(\d{1,3}.){3}.\d{1,3}')
    master_mask=`ifconfig ${master_ifac} |awk '/inet/{print $4}'|grep -oP '(\d{1,3}.){3}.\d{1,3}'`
    gw=`route -n |awk '$1~"0.0.0.0"{print $2}'`

    second_ip=`ifconfig ${second_ifac} |awk '/inet/{print $2}'|grep -oP '(\d{1,3}.){3}.\d{1,3}'`
    second_mask=`ifconfig ${second_ifac} |awk '/inet/{print $4}'|grep -oP '(\d{1,3}.){3}.\d{1,3}'`

    if [[ $(ls /etc/network |grep 'bak'|wc -l) -eq 0 ]];then
        local time=`date +%Y%m%d%H%M`
        cp /etc/network/interfaces /etc/network/interfaces.bak${time}
    fi

    >/etc/network/interfaces

    [ ! -z ${master_ifac} ] && \
    echo -e "auto lo ${master_ifac} ${second_ifac} br0 \nallow-ovs br0" >>/etc/network/interfaces
    echo -e "iface lo inet loopback\niface ${master_ifac} inet static\n\taddress 0\n " >>/etc/network/interfaces
    echo -e "iface br0 inet static\n  address ${master_ip}\n  netmask ${master_mask}\n  gateway ${gw}\n" >>/etc/network/interfaces
    [ ! -z ${second_ip} ] && \
    echo -e "iface ${second_ifac} inet static\n  address ${second_ip}\n  netmask ${second_mask}\n" >>/etc/network/interfaces


    cat <<EOF >setbr0.sh
#!/bin/bash

ifconfig master_ifac 0
ovs-vsctl add-br br0
ovs-vsctl add-port br0 master_ifac
/etc/init.d/openvswitch-switch restart
ifup br0
ifconfig br0 master_ip netmask master_mask up
route add -net 0.0.0.0/0 gw gw_ip

EOF
    sed -i "s/master_mask/${master_mask}/g" setbr0.sh
    sed -i "s/master_ifac/${master_ifac}/g" setbr0.sh
    sed -i "s/master_ip/${master_ip}/g" setbr0.sh
    sed -i "s/gw_ip/${gw}/g" setbr0.sh
    chmod +x setbr0.sh
    cat setbr0.sh
    nohup ./setbr0.sh &
    sleep 10

    cat /etc/network/interfaces
    echo "========================================================="
    echo "Need reboot to let new network configuration take effect "
}


init_ovsnet()
{
    [ $(virsh net-list |grep ovs-net|wc -l) -ne 0 ] && logger info "ovs-net exist" && virsh net-list &&  return 0
    cat <<_EOF >ovs-net.xml
<network>
 <name>ovs-net</name>
 <forward mode='bridge'/>
 <bridge name='br0'/>
 <virtualport type='openvswitch'/>
 <portgroup name='default' default='yes'>
 </portgroup>
</network>
_EOF
    virsh net-define ovs-net.xml && \
    virsh net-start ovs-net && \
    virsh net-autostart ovs-net && \
    virsh net-list
}

init_check()
{
    logger warning "Begin to check init:"
    sleep 3
    echo

    logger warning "check virsh net-list......"
    [[ $(virsh net-list |grep ovs-net |wc -l) -eq 0 ]] && \
    logger error "virsh net-list is not init well."
    virsh net-list|grep ovs-net

    logger warning "check virsh pool-list......"
    [[ $(virsh pool-list |grep active |wc -l) -ne 6 ]] && \
    logger error "virsh pool-list is not init well."
    virsh pool-list |grep -w active

    logger warning "check ceph......"
    [[ $(ceph -s |grep health |wc -l) -ne 1 ]] && \
    logger error "ceph is not init."
    ceph -s |grep health


    logger warning "check cephfs......"
    [[ $(df -h |grep cephfs |wc -l) -ne 1 ]] && \
    logger error "cephfs is not init."
    logger info "df -h |grep cephfs"
    df -h |grep cephfs


    logger warning "check set br0......"
    [[ $(ovs-vsctl show|grep br0 |wc -l) -eq 0 ]] && \
    logger error "setbr0 is not init."
    logger info "ovs-vsctl show"
    ovs-vsctl show |grep br0


    logger warning "check iptables......"
    [[ $(iptables-save  |grep 32200 |wc -l) -eq 0 ]] && \
    logger error "iptables is not init."
    logger info "iptables-save"
    iptables-save |grep 32200

    logger warning "check kernel version......"
    [[ $(uname -a |grep -w '3.16.56-1+deb8u1' |wc -l) -eq 0 ]] && \
    logger error "kernel version is not init."
    logger info "uname -a"
    uname -a
}

dis_usage()
{
cat <<EOF
Usage:26cmp_init.sh [OPTIONS]
                    -h                   # help How to use
                    -a                   # init all module,include ceph,cephfs,ovs,libvirt pool,libvirt net.
                    -k                   # check whether init is all ok.
                    -c                   # only init ceph
                    -p                   # only init libvirt pool
                    -s                   # only init cephfs
                    -f                   # only init fwrule(iptables)
                    -n                   # only init interfaces
EOF
}

#Option deal with
if [ -z "$1" ];then
    dis_usage
    logger error "Options is Error!"
    exit 1
fi

TEMP=`getopt -o uacpsefnokh -l update,all,ceph,pool,cephfs,env,fwrule,network,ovs,check,help  -n 'Error' -- "$@"`
#echo '$TEMP' $TEMP
eval set -- "$TEMP"


check_role
while [ ! -z $1 ]
do
    case "$1" in
        -u|--update)
            ## update kernel
            init_kernel
            shift 1
            ;;
        -h|--help)
            ## display how to use the script
            dis_usage
            shift 1
            ;;
        -c|--ceph)
            ##init ceph
            init_ceph
            shift 1
            ;;
        -p|--pool)
            ##init virsh pool
            init_virshsecret
            init_virshpool
            shift 1
            ;;
        -s|--cephfs)
            ##init cephfs
            init_cephfs
            shift 1
            ;;
        -e|--env)
            ##init buildkvm environment
            init_buildkvm_env
            shift 1
            ;;
        -f|--fwrule)
            ##init fwrule-iptables
            init_fwrule
            shift 1
            ;;
        -n|--network)
            ##init network
            init_interface
            shift 1
            ;;
        -o|--ovs)
            ##init virsh ovs-net
            init_ovsnet
            shift 1
            ;;
        -k|--check)
            ## check init
            init_check
            shift 1
            ;;
        -a|--all)
            ## execute all step
            init_kernel
            init_ceph
            init_virshsecret
            init_virshpool
            init_cephfs
            init_buildkvm_env
            init_fwrule
            init_interface
            init_ovsnet
            init_check
            shift 1
            ;;
        *)
            break ;;
    esac
done
exit 0