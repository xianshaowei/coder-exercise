#!/bin/bash
# migrate vm from one ceph pool to another
# author : hxfn1692
# date   : 2016.03.21
# usage  : xml -> recv_origin + send_origin -> recv_diff + send_diff ...-> clean

#set -e

vm="$2"
remote_ip="$3"
homedir="/home/vm"
flagdir="${homedir}/var/lib/build_vm_flag"
logdir="${homedir}/var/log"
logfile="${logdir}/migrate_vm.log"
cephfs="/home/vm/cephfs"
build_kvm="$cephfs/bin/build_kvm.sh"
ip=`hostname -i`
port=19000

FGC_START="\033[1;"
FGC_END="\033[0m"
FGC_YELLOW="33m"
FGC_RED="31m"
FGC_GREEN="32m"
FGC_WHITE="37m"

logger()
{
    local level=$1
    shift
    local msg="$@"

    local color=""
    local msg_datetime=$(date +"[%F %T]")

    case "$level" in
        [Ii][Nn][Ff][Oo]*)
            color=$FGC_GREEN
            ;;
        [Ww][Aa][Rr][Nn]*)
            color=$FGC_YELLOW
            ;;
        [Ee][Rr][Rr]*)
            color=$FGC_RED
            ;;
        *)
            color=$FGC_WHITE
            ;;
    esac
    echo -e $msg_datetime $level "${FGC_START}${color}$msg${FGC_END}" | tee -a $logfile 1>&2
}


if [ -z "$2" ];then
    echo "Usage: $0 {xml|recv_origin|send_origin|recv_diff|send_diff|clean} hostname [ip]"
    exit
fi

if [ "$1" == "send_origin" ] && [ -z "$3" ];then
    echo "Usage: $0 send_origin <hostname> <remote_ip>"
    exit
fi

if [ "$1" == "send_diff" ] && [ -z "$3" ];then
    echo "Usage: $0 send_diff <hostname> <remote_ip>"
    exit
fi

if [ "$1" == "recv_origin" ] && [ -z "$3" ];then
    echo "Usage: $0 recv_origin <hostname> <remote_ip>"
    exit
fi

if [ "$1" == "recv_diff" ] && [ -z "$3" ];then
    echo "Usage: $0 recv_diff <hostname> <remote_ip>"
    exit
fi

check_vm_exist(){
    logger INFO "Check /home/vm/etc/vmlist item for ${vm}..."
    if [ $(awk -v NAME="$vm" '$1==NAME' /home/vm/etc/vmlist|wc -l) -eq 0 ];
    then
        logger ERROR "no item pre-define in vmlist! define it first"
        exit 1
    else
        awk -v NAME="$vm" '$1==NAME' /home/vm/etc/vmlist
    fi

    logger INFO "Check virsh list"
    logger INFO $(virsh list --all|awk -v NAME="$vm" '$2==NAME')
    if [ $(virsh list --all|awk -v NAME="$vm" '$2==NAME'|wc -l) -gt 0 ];
    then
        if [ $1 == "xml" ];
        then
            logger WARN "${vm} has already been defined in virsh, skip it"
            logger INFO `virsh list --all|awk -v NAME="$vm" '$2==NAME'`
            exit 0
        fi
    else
        if [ $1 == "receive" ];
        then
            logger WARN "${vm} not defined in virsh, skip receiving action"
            exit 1
        fi
    fi
}

prepare(){
    if [ ! -d $logdir ];
    then
        mkdir -p $logdir
    fi

    if [ ! -f $logfile ];
    then
        touch $logfile
    fi

    for pkg in screen pv
    do
        if [ $(dpkg-query -W -f='${Status}' ${pkg} 2>/dev/null | grep -c "ok installed") -eq 0 ];
        then
            apt-get --yes install ${pkg};
        fi
    done
}

xml(){
    prepare
    check_vm_exist xml

    logger INFO "Touching build flag..."
    touch "$flagdir/${vm}.disk.data"
    touch "$flagdir/${vm}.disk.image"
    touch "$flagdir/${vm}.disk.swap"

    logger INFO "Building $vm XML..."
    bash $build_kvm

    logger INFO "Show vm..."
    virsh list --all

    logger INFO "Dump vm XML..."
    virsh dumpxml ${vm} | grep rbd
}


check_screen(){
    logger INFO "Checking ${vm} screen session..."
    if [ $(screen -ls | grep -c ${vm}) -eq 0 ];
    then
        logger INFO "Congratulation ^_^ ${vm} no disk transfer now."
    else
        logger ERROR "${vm} disk is transmitting!! skip it"
        exit 1
    fi
}

allow_fw_port(){
    logger INFO "Before transmission, Allow nc port ${port},$((${port}+1)),$((${port}+2)) for host ${remote_ip}"
    if [ $(iptables-save|grep -c -E "${remote_ip}.*${port}") -eq 0 ];then
        logger INFO "Add iptables rule"
        logger CMD "iptables -I INPUT -p tcp -s ${remote_ip}/32 -m multiport --dports ${port},$((${port}+1)),$((${port}+2)) -j ACCEPT"
        iptables -I INPUT -p tcp -s ${remote_ip}/32 -m multiport --dports ${port},$((${port}+1)),$((${port}+2)) -j ACCEPT
        iptables-save|grep "multiport dports ${port},$((${port}+1)),$((${port}+2))"
    else
        logger WARN "already allow nc port"
        iptables-save|grep "dports ${port},$((${port}+1)),$((${port}+2))"
    fi
}

deny_fw_port(){
    logger INFO "After transmission, Deny nc port ${port},$((${port}+1)),$((${port}+2)) for host ${remote_ip}"
    if [ $(iptables-save|grep -c -E "${remote_ip}.*${port}") -eq 0 ];then
        logger INFO "iptables don't contain allow nc port rule"
    else
        iptables-save|grep "dports ${port},$((${port}+1)),$((${port}+2))"|while read rule;
        do
            d_rule=$(echo $rule|sed 's/-A INPUT/-D INPUT/')
            logger CMD "iptables ${d_rule}"
            iptables ${d_rule}
        done
        logger INFO "Delete allow nc rule done."
    fi
}

recv_origin(){
    prepare
    check_vm_exist receive

    logger INFO "******* origin RBD receiving mode ******"
    logger INFO "Get sys,swap,data rbd name from XML..."
    sys_rbd=$(virsh dumpxml ${vm}|grep -E 'rbd.*sys'|cut -d "'" -f 4)
    swap_rbd=$(virsh dumpxml ${vm}|grep -E 'rbd.*swap'|cut -d "'" -f 4)
    data_rbd=$(virsh dumpxml ${vm}|grep -E 'rbd.*data'|cut -d "'" -f 4)
    logger INFO "$sys_rbd"
    logger INFO "$swap_rbd"
    logger INFO "$data_rbd"

    check_screen
    allow_fw_port

    logger INFO "Begin receiving origin disk ..."
    logger CMD "nc -l -vv -s ${ip} -p ${port}|pv|rbd --image-format 2 import - ${sys_rbd}"
    screen -dmS ${vm}_sys bash -c "nc -l -vv -s ${ip} -p ${port}|pv|rbd --image-format 2 import - ${sys_rbd} && rbd snap create ${sys_rbd}@snap1; alert.py -d '{\"type\":\"migrate_vm\"}' -m \"origin ${sys_rbd} transmission done\""
    logger CMD "nc -l -vv -s ${ip} -p $((${port} + 1))|pv|rbd --image-format 2 import - ${swap_rbd}"
    screen -dmS ${vm}_swap bash -c "nc -l -vv -s ${ip} -p $((${port} + 1))|pv|rbd --image-format 2 import - ${swap_rbd} && rbd snap create ${swap_rbd}@snap1; alert.py -d '{\"type\":\"migrate_vm\"}' -m \"origin ${swap_rbd} transmission done\""
    logger CMD "nc -l -vv -s ${ip} -p $((${port} + 2))|pv|rbd --image-format 2 import - ${data_rbd}"
    screen -dmS ${vm}_data bash -c "nc -l -vv -s ${ip} -p $((${port} + 2))|pv|rbd --image-format 2 import - ${data_rbd} && rbd snap create ${data_rbd}@snap1; alert.py -d '{\"type\":\"migrate_vm\"}' -m \"origin ${data_rbd} transmission done\""
    logger INFO "screens to receive disk data"
    screen -ls

    logger INFO "alert to info to blackhole"
    #alert.py -d '{"type":"migrate_vm"}' -m "origin ${sys_rbd} transmission done"
    #alert.py -d '{"type":"migrate_vm"}' -m "origin ${swap_rbd} transmission done"
    #alert.py -d '{"type":"migrate_vm"}' -m "origin ${data_rbd} transmission done"

    logger INFO "Create snap1 for vm three rbd"
    logger CMD "rbd snap create ${sys_rbd}@snap1"
    logger CMD "rbd snap create ${swap_rbd}@snap1"
    logger CMD "rbd snap create ${data_rbd}@snap1"
}


check_origin_vm_exist(){
    logger INFO "Check origin vm ${vm} exist..."
    if [ $(virsh list --all|awk -v NAME="$vm" '$2==NAME'|wc -l) -gt 0  ]; then
        logger INFO $(virsh list --all|awk -v NAME="$vm" '$2==NAME')
    else
        logger ERROR "origin vm ${vm} doesn't exist!"
        exit 1
    fi
}

send_origin(){
    prepare

    check_origin_vm_exist

    vm_status=$(virsh list --all|awk -v NAME="$vm" '$2==NAME'|awk '{print $3}')
    if [[ ${vm_status} != shut* ]];then
        logger WARN "vm ${vm} is ${vm_status} NOT shut off"
    else
        logger INFO "vm ${vm} is ${vm_status}"
        logger INFO "This is the last one transmission ^_^"
    fi

    logger INFO "******* origin RBD sending mode ******"
    logger INFO "Get sys,swap,data PATH of ${vm}..."
    sys_disk=$(virsh dumpxml ${vm}|grep -E 'rbd.*sys'|cut -d "'" -f 4)
    swap_disk=$(virsh dumpxml ${vm}|grep -E 'rbd.*swap'|cut -d "'" -f 4)
    data_disk=$(virsh dumpxml ${vm}|grep -E 'rbd.*data'|cut -d "'" -f 4)
    logger INFO "$sys_disk"
    logger INFO "$swap_disk"
    logger INFO "$data_disk"

    logger INFO "Create snapshot before sending"
    logger CMD "rbd snap create ${sys_disk}@snap1"
    logger CMD "rbd snap create ${swap_disk}@snap1"
    logger CMD "rbd snap create ${data_disk}@snap1"
    rbd snap create ${sys_disk}@snap1
    rbd snap create ${swap_disk}@snap1
    rbd snap create ${data_disk}@snap1

    check_screen

    logger INFO "Begin sending origin disk data to ${remote_ip}"
    logger CMD "rbd export ${sys_disk}@snap1 -|pv|nc -q 10 ${remote_ip} ${port}"
    screen -dmS ${vm}_sys bash -c "rbd export ${sys_disk}@snap1 -|pv|nc -q 10 ${remote_ip} ${port}"
    logger CMD "rbd export ${swap_disk}@snap1 -|pv|nc -q 10 ${remote_ip} $((${port} + 1))"
    screen -dmS ${vm}_swap bash -c "rbd export ${swap_disk}@snap1 -|pv|nc -q 10 ${remote_ip} $((${port} + 1))"
    logger CMD "rbd export ${data_disk}@snap1 -|pv|nc -q 10 ${remote_ip} $((${port} + 2))"
    screen -dmS ${vm}_data bash -c "rbd export ${data_disk}@snap1 -|pv|nc -q 10 ${remote_ip} $((${port} + 2))"
    screen -ls
}

recv_diff(){
    check_vm_exist receive
    check_screen

    logger INFO "******* diff RBD receiving mode ******"
    logger INFO "Get sys,swap,data rbd name from XML..."
    sys_rbd=$(virsh dumpxml ${vm}|grep -E 'rbd.*sys'|cut -d "'" -f 4)
    swap_rbd=$(virsh dumpxml ${vm}|grep -E 'rbd.*swap'|cut -d "'" -f 4)
    data_rbd=$(virsh dumpxml ${vm}|grep -E 'rbd.*data'|cut -d "'" -f 4)
    logger INFO "$sys_rbd"
    logger INFO "$swap_rbd"
    logger INFO "$data_rbd"

    allow_fw_port

    logger INFO "Begin receiving diff disk ..."
    logger CMD "nc -l -vv -s ${ip} -p ${port}|pv|rbd import-diff - ${sys_rbd}"
    screen -dmS ${vm}_sys bash -c "nc -l -vv -s ${ip} -p ${port}|pv|rbd import-diff - ${sys_rbd} && alert.py -d '{\"type\":\"migrate_vm\"}' -m \"diff ${sys_rbd} transmission done\""
    logger CMD "nc -l -vv -s ${ip} -p $((${port} + 1))|pv|rbd import-diff - ${swap_rbd}"
    screen -dmS ${vm}_swap bash -c "nc -l -vv -s ${ip} -p $((${port} + 1))|pv|rbd import-diff - ${swap_rbd} && alert.py -d '{\"type\":\"migrate_vm\"}' -m \"diff ${swap_rbd} transmission done\""
    logger CMD "nc -l -vv -s ${ip} -p $((${port} + 2))|pv|rbd import-diff - ${data_rbd}"
    screen -dmS ${vm}_data bash -c "nc -l -vv -s ${ip} -p $((${port} + 2))|pv|rbd import-diff - ${data_rbd} && alert.py -d '{\"type\":\"migrate_vm\"}' -m \"diff ${data_rbd} transmission done\""
    logger INFO "screens to receive ${vm} disk diff data"
    screen -ls
}


send_diff(){
    prepare

    check_origin_vm_exist

    vm_status=$(virsh list --all|awk -v NAME="$vm" '$2==NAME'|awk '{print $3}')
    if [[ ${vm_status} != shut* ]];
    then
        logger WARN "vm ${vm} is ${vm_status} NOT shut off"
        logger WARN "****** After shut off, need send_diff again! ******"
    else
        logger INFO "vm ${vm} is ${vm_status}, this is the last diff"
    fi

    logger INFO "******* diff RBD sending mode ******"
    logger INFO "Get sys,swap,data PATH of ${vm}..."
    sys_disk=$(virsh dumpxml ${vm}|grep -E 'rbd.*sys'|cut -d "'" -f 4)
    swap_disk=$(virsh dumpxml ${vm}|grep -E 'rbd.*swap'|cut -d "'" -f 4)
    data_disk=$(virsh dumpxml ${vm}|grep -E 'rbd.*data'|cut -d "'" -f 4)
    logger INFO "$sys_disk"
    logger INFO "$swap_disk"
    logger INFO "$data_disk"

    logger INFO "Create snapshot before sending"
    snap_list=""
    for i in ${sys_disk} ${swap_disk} ${data_disk};
    do
        last_snap=$(rbd snap ls ${i}|sort -n|awk '$2 ~ /snap[0-9]/ {print $2}'|tail -1)
        last_snap_num=$(echo ${last_snap}|sed 's/[^0-9]*//g')
        if [ -z $last_snap_num ];
        then
            logger ERROR "no snap* before, at least need a snap1 first!"
            exit
        fi
        new_snap_num=$((${last_snap_num} + 1))
        logger CMD "rbd snap create ${i}@snap${new_snap_num}"
        rbd snap create ${i}@snap${new_snap_num}
        snap_list=${snap_list}:${new_snap_num}
    done

    check_screen

    logger INFO "Begin sending *diff* disk data to ${remote_ip}"
    echo $snap_list
    sys_snap_num=$(echo $snap_list|cut -d ":" -f2)
    last_sys_snap="snap"$((${sys_snap_num} - 1))
    swap_snap_num=$(echo $snap_list|cut -d ":" -f3)
    last_swap_snap="snap"$((${swap_snap_num} - 1))
    data_snap_num=$(echo $snap_list|cut -d ":" -f4)
    last_data_snap="snap"$((${data_snap_num} - 1))

    logger CMD "rbd export-diff --from-snap ${last_sys_snap} ${sys_disk}@snap${sys_snap_num} -|pv|nc ${remote_ip} ${port}"
    screen -dmS ${vm}_sys bash -c "rbd export-diff --from-snap ${last_sys_snap} ${sys_disk}@snap${sys_snap_num} -|pv|nc -q 10 ${remote_ip} ${port}"
    logger CMD "rbd export-diff --from-snap ${last_swap_snap} ${swap_disk}@snap${swap_snap_num} -|pv|nc -q 10 ${remote_ip} $((${port} + 1))"
    screen -dmS ${vm}_swap bash -c "rbd export-diff --from-snap ${last_swap_snap} ${swap_disk}@snap${swap_snap_num} -|pv|nc -q 10 ${remote_ip} $((${port} + 1))"
    logger CMD "rbd export-diff --from-snap ${last_data_snap} ${data_disk}@snap${data_snap_num} -|pv|nc -q 10 ${remote_ip} $((${port} + 2))"
    screen -dmS ${vm}_data bash -c "rbd export-diff --from-snap ${last_data_snap} ${data_disk}@snap${data_snap_num} -|pv|nc -q 10 ${remote_ip} $((${port}+2))"
    logger INFO "screens to send ${vm} diff disk "
    screen -ls
}

clean(){
    logger INFO "***** clean stage *****"
    deny_fw_port

    vm_status=$(virsh list --all|awk -v NAME="$vm" '$2==NAME'|awk '{print $3}')
    if [[ ${vm_status} != shut* ]];then
        logger WARN "vm ${vm} is ${vm_status} NOT shut off, skip clean stage"
        exit
    else
        logger INFO "vm ${vm} is ${vm_status}, go on clean stage"
    fi

    logger INFO "Clean up ${vm} flags, undefine, vmlist item"
    read -p "Clean $vm, Are you sure?(y/n):" ans

    if [ "$ans" = "y" ]
    then
        logger INFO 'Clean build flag...'
        rm -i $flagdir/${vm}.disk.data
        rm -i $flagdir/${vm}.disk.image
        rm -i $flagdir/${vm}.disk.swap
        rm -i $flagdir/${vm}.uuid

        logger INFO "Undefine $vm ..."
        virsh undefine ${vm}

        logger INFO "Update vmlist ..."
        sed --follow-symlinks -i "/^[[:space:]]*${vm}[[:space:]]/d" /home/vm/etc/vmlist
    fi
}

check(){
    if [ -d "$cephfs" ]
    then
        logger INFO "Check cephfs done."
    else
        logger ERROR "$cephfs not found"
        exit 1
    fi
}

case "$1" in
    xml)
        check
        xml
        ;;
    recv_origin)
        recv_origin
        ;;
    send_origin)
        send_origin
        ;;
    recv_diff)
        recv_diff
        ;;
    send_diff)
        send_diff
        ;;
    clean)
        clean
        ;;
    *)
        echo "Usage: $0 {xml|recv_origin|send_origin|recv_diff|send_diff|clean} hostname"
        ;;
esac