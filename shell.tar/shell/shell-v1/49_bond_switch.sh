#!/bin/bash

#Author: 鲜伟
#Date: 2019-5-6
#说明： 白羊座的宿主节点bond接口命名为swacc_netid,子接口名字为vxlan_netid_0和vxlan_netid_1
#      其中netid为数字编号,比如vxlan_4011_0和vxlan_4011_1
#作用： 如果IP地址的四分位的最后位为奇数，这将流量切换到"_1"对应的子接口；如果位偶数，这将流量切换到"_0"对应的子接口
#      例如10.120.123.11会将流量切换到vxlan_netid_1而10.120.123.12会将流量切换到vxlan_netid_1
#      从而实现了，CVG下卦的计算节点流量均衡

cvg_ip=$1

if [ -z "$cvg_ip" ]
then
    echo "Usage: $0 [cvg_ip]"
    exit 0
fi

if [ `ovs-vsctl show | grep remote |awk '{print $NF}' |grep ${cvg_ip} |wc -l` == 0 ]
then
    echo "Error,cvg_ip is error,pls check."
    exit 0
fi

netid=`ovs-vsctl show | grep remote | grep $cvg_ip | awk '{print $2}' | awk -F\" '{print $2}'`

active=`ifconfig eth0 | awk '/addr:/{print $2}' | awk -F. '{print $NF}'`
# 取模，结果为0或1
let "active=active%2"

for id in $netid
do
    echo "Check acc_$id..."
    # 获取bridge下的Port名;
    ports=`ovs-vsctl list-ports swacc_$id | grep "${id}"`

    for port in $ports
    do
        # bond切换
        echo ovs-appctl bond/set-active-slave $port vxlan_${id}_"$active"
        ovs-appctl bond/set-active-slave $port vxlan_${id}_"$active"
    done
done
