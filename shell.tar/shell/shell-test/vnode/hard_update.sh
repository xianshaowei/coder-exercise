#!/usr/bin/env bash


# 升级Raid
wget http://hwteam:iwant2download@hw.x.netease.com:8808/tools/fwhub.py -O /home/xianwei01/fwhub.py
python /home/xianwei01/fwhub.py -i 3 -u -y -f
echo "==========================Need restart========================="



# 升级网卡驱动
mkdir /home/xianwei01/tmp/
tar zxf /home/xianwei01/ixgbe-5.5.5.tar.gz -C /home/xianwei01/tmp/
cd /home/xianwei01/tmp/ixgbe-5.5.5/src/
make install
modinfo ixgbe |grep version


mkdir /home/xianwei01/tmp/
tar xzf /home/xianwei01/ixgbevf-4.5.3.tar.gz -C /home/xianwei01/tmp/
cd /home/xianwei01/tmp/ixgbevf-4.5.3/src/
make install


# 检查
python /home/xianwei01/fwhub.py -l |grep RAID ;modinfo ixgbe |grep version|head -1 ;modinfo ixgbevf |grep version|head -1
