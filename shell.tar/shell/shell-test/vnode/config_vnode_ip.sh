#!/bin/bash

ip_excel_list=/home/xianwei01/vnodeip.txt
dest_file=/etc/network/interfaces


# 录入掩码和网关
eth0Netmask='255.255.254.0'     # 必须，根据实际IP进行调整
eth1Netmask='255.255.252.0'     # 必须，根据实际IP进行调整
eth2Netmask='255.255.254.0'     # 必须，根据实际IP进行调整
eth3Netmask='255.255.255.0'     # 必须，根据实际IP进行调整
gatewayIP='10.90.208.1'         # 必须，根据实际IP进行调整

#判断是否存在IP列表
if test ! -f ${ip_excel_list}
then
  echo "ip execl iplist is not exist."
  exit 1
fi

#判断参数
if [ $? != 0  ];then
  echo " vnodeip.txt not exist; "
  exit 1
fi

#判断原始interface文件是否备份
if test ! -f ${dest_file}.OSInstall
then
  cp ${dest_file} ${dest_file}.OSInstall
fi

# 从IP列表提取接口IP
# awk需要传入shell变量
eth0_ip=`ifconfig eth0|grep -w inet |awk -F'[\:]' '{print $2}'|awk '{print $1}'`
eth1_ip=$(cat ${ip_excel_list} |awk -v eth0IP=${eth0_ip} '{if($1==eth0IP) print $2}' )
eth2_ip=$(cat ${ip_excel_list} |awk -v eth0IP=${eth0_ip} '{if($1==eth0IP) print $3}' )
eth3_ip=$(cat ${ip_excel_list} |awk -v eth0IP=${eth0_ip} '{if($1==eth0IP) print $4}' )


cat <<EOF >${dest_file}
auto eth0
iface eth0 inet static
    address 0
    up ethtool -G eth0 rx 4096 tx 4096

auto eth1
iface eth1 inet static
    address eth1_ip
    netmask eth1Netmask
    gateway gatewayIP
    up ethtool -G eth1 rx 4096 tx 4096

auto eth2
iface eth2 inet static
    address 0
    up ethtool -G eth2 rx 4096 tx 4096


auto eth3
iface eth3 inet static
    address eth3_ip
    netmask eth3Netmask
    up ethtool -G eth3 rx 4096 tx 4096

auto lo
iface lo inet loopback

EOF


sed -i "s/eth1_ip/${eth1_ip}/" ${dest_file}
sed -i "s/eth3_ip/${eth3_ip}/" ${dest_file}

sed -i "s/eth1Netmask/${eth1Netmask}/" ${dest_file}
sed -i "s/eth3Netmask/${eth3Netmask}/" ${dest_file}

sed -i "s/gatewayIP/${gatewayIP}/" ${dest_file}

echo "cat ${dest_file}"
cat ${dest_file}
