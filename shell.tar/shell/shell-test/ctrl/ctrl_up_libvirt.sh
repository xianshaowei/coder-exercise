#!/bin/bash


# 添加源
cat <<EOF >/etc/apt/sources.list.d/21-jessie-backports.list
deb http://archive.debian.org/debian/  jessie-backports main non-free contrib
deb-src http://archive.debian.org/debian/ jessie-backports main non-free contrib
EOF

# 升级libvirt
apt-get -o Acquire::Check-Valid-Until=false update
apt-get install libvirt-clients libvirt-daemon libvirt-daemon-system libvirt0 -t jessie-backports -o Acquire::Check-Valid-Until=false
dpkg -l |grep libvirt