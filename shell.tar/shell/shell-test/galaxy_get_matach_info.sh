#!/usr/bin/env bash

# 通过资产号得到机柜位置

if [ -z $1 ];then
   echo " Usage $0 iplist.txt"
   exit 1
fi


for i in `cat $1|awk '{print $1}'`
do
echo -n "$i "
curl -X GET \
  https://galaxy.nie.netease.com/api/v1/assets/@$i \
  -H 'Cache-Control: no-cache' \
  -H 'Content-Type: application/json' \
  -H 'Postman-Token: 22b2f5ae-af49-41e7-ac25-259dfaa74561' \
  -H 'X-Auth-Project: cld' \
  -H 'X-Auth-Token: RjxMURYS7At0G69OxqK6VmrHT4N6uN%2BEGahVY8aZhN%2Fz8yaTpnxKWfhOqwp9tdcL591xiHgocwNo%0ArcSxjlP8RHtFmqNtpsG4unsaSL3N0yQef1n7SNYGulx66keNOIlyWsLEzA8XgN5DBpGGPnB5B5av%0AQuvjToEp3N45bc0cZPw%3D%0A' \
  |awk -F'[\,]' '{print $23,$24,$25}' |awk -F'[\"]' '{print $4$8$12}' 2>/dev/null

done


