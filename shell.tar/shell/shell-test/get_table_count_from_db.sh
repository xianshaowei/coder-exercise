#!/bin/bash

DB='cld_api_server_bj'
HOST='skyline-cld-113002-m.hz.dumbo.nie.netease.com'
USER='projsa'
PASSWD='a40c9080d04d11e7a1634c32759562c9'

mysql -u${USER} -p${PASSWD} -h${HOST} -e "use ${DB} ;show tables;" >/tmp/db_tables.txt
#mysql -uprojsa  -pa40c9080d04d11e7a1634c32759562c9 -e "use cld_api_server_bj; show tables;"

for i in `cat /tmp/db_tables.txt|awk 'NR>1{print $0}'`
do
    echo -n "$i :  "
    mysql -u${USER} -p${PASSWD}  -h${HOST} -e "use ${DB} ; select count(*) from $i" 2>/dev/null |grep -P '\d'
done