#!/usr/bin/env bash

# Program:
#   Program for cube release upgrade.
# History:
#   2018/11/28  first release
#   2018/11/29  second release. add input options
#   2018/12/03  3th release. add logger function
#   2019/01/16  4th release. use global cube config dir and replair -d logical
# Author:
#   Wings/xianwei 13880675749 xianwei01@corp.netease.com


logfile="/tmp/cube-admin.log"

FGC_START="\033[1;"
FGC_END="\033[0m"
FGC_YELLOW="33m"
FGC_RED="31m"
FGC_GREEN="32m"
FGC_WHITE="37m"


CONFIGDIR=/home/cld/conf/cube
#CONFIGDIR=/etc/cube
PATH=/usr/local/apache-maven-3.5.2/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/opt/puppetlabs/bin
export PATH

logger()
{
    local level=$1
    shift
    local msg="$@"

    local color=""
    local msg_datetime=$(date +"[%F %T]")

    case "$level" in
        [Ii][Nn][Ff][Oo]*)
            color=$FGC_GREEN
            ;;
        [Ww][Aa][Rr][Nn]*)
            color=$FGC_YELLOW
            ;;
        [Ee][Rr][Rr]*)
            color=$FGC_RED
            ;;
        *)
            color=$FGC_WHITE
            ;;
    esac
    echo -e $msg_datetime $level "${FGC_START}${color}$msg${FGC_END}" | tee -a $logfile 1>&2
}


dis_usage()
{
cat <<EOF
Usage:cube-admin [OPTIONS] <version>
                 -h                   #help How to use
                 -d                   #delete dockers of old version.must need update finish
                 -u <version>         #update cube version
                 -r <version>         #remove dockers of designated version
                 -g                   #get cube version of LBC effective
EOF
}

get_lbc_vip_region()
{
    #Function: define a dic: local ip address ---> lbc vip address and it's region
    declare -A LBC_VIP_DIC
    LBC_VIP_DIC=(
         ["10.160.82.227"]="10.160.79.202 cld_docker_test" \
         ["10.160.82.151"]="10.160.79.203 cld_bj_gray" \
         ["10.82.68.11"]="10.204.2.111 cld_bj_zw" \
         ["10.204.31.211"]="10.204.2.113 cld_hz_dg" \
         ["10.191.176.50"]="10.192.21.83 cld_hz_ba_vm" \
         ["10.191.164.52"]="10.192.21.84 cld_hz_ba"
         ["10.191.200.126"]="10.192.59.186 cld_hz_ba_pavo"
    )
    echo "${LBC_VIP_DIC[$1]}"
}

get_cube_version()
{
    #Function: get lbc vip and region according to local ip address.

    local_ip=`ifconfig |grep inet|awk '{print $2}'|sed 's/addr://g' |grep -vE "172.|127."`
    lbc_vip=`get_lbc_vip_region ${local_ip} |awk '{print $1}'`
    lbc_region=`get_lbc_vip_region ${local_ip} |awk '{print $2}'`
    #echo ${lbc_vip}
    #echo ${lbc_region}
    logger info "curl -X GET http://${lbc_vip}:19090/api/v2/cube/version"
    curl -X GET \
          http://${lbc_vip}:19090/api/v2/cube/vpcs \
          -H 'Cache-Control: no-cache' \
          -H 'Content-Type: application/json' \
          -H 'Postman-Token: 22b2f5ae-af49-41e7-ac25-259dfaa74561' \
          -H 'X-Auth-Project: cld' \
          -H "X-Auth-Region: ${lbc_region}" \
          -H 'X-Auth-Token: YAK1%2FyCCC8gGbpTA239sUR9cqbtT%2Bqrp%2BHEQtNhCtpXO3j%2FT9GxVYn7qrwH0QIL%2BmoiVy2UgaCjv%0AIOwSLzUhsIXYsV7rD5b2iM4cKu7QeP%2FcXscSeiquD4W97xeIgj28xH5PtFdc2iZ8yA9ISkN8MyA%2B%0AbPyEyYL3%2F%2BMjl6n3xW0%3D%0A'

}


start_cube19090()
{
    #Function: start 3 docker:cube-api/cube-controller/cube-work,which service port is 19090

    if [ -z "$1" ];then dis_usage; exit 1; fi
    VERSION=$1
    [ `echo ${VERSION}|wc -m` -lt 9 ] && logger error "Inpute version is error.pls check." && exit 1

    DOCKER_HUB="dockerhub.nie.netease.com"
    mkdir -p /home/cld/log/cube

    netstat -an |awk '{print $4}'|grep "0.0.0.0:19090" >/dev/null >/dev/null
    cube_port_exist_flag=$(echo $?)

    if [  ${cube_port_exist_flag} == 0  ];then
        #if cube-api is already running,raise error.
        logger error "Error,cube-api is already running,pls check docker status."
        exit 1
    fi
    logger info "docker run cube-api"
    docker run -d --name=cube-api --net=host \
       -v /home/cld/log/cube/:/var/log/cube/ \
       -v ${CONFIGDIR}/cube.conf:/etc/cube/cube.conf \
       $DOCKER_HUB/skyline-cld/cld-api-server:$VERSION \
       --module api --config-file=/etc/cube/cube.conf \
       --log-file=/var/log/cube/api.log
    [ $? != 0 ] && logger error "cube-api not be created!" \
       && docker rename cube-api-old cube-api \
       && docker rename cube-worker-old cube-worker \
       && docker rename cube-controller-old cube-controller \
       && exit 1

    logger info "docker run cube-controller"
    docker run -d --name=cube-controller --net=host \
       -v /home/cld/log/cube/:/var/log/cube/ \
       -v ${CONFIGDIR}/cube.conf:/etc/cube/cube.conf \
       $DOCKER_HUB/skyline-cld/cld-api-server:$VERSION \
       --module controller --config-file=/etc/cube/cube.conf \
       --log-file=/var/log/cube/controller.log
    [ $? != 0 ] && logger error "cube-controller not be created!" && exit 1

    logger info "docker run cube-worker"
    docker run -d --name=cube-worker --net=host \
       -v /home/cld/log/cube/:/var/log/cube/ \
       -v ${CONFIGDIR}/cube.conf:/etc/cube/cube.conf \
       $DOCKER_HUB/skyline-cld/cld-api-server:$VERSION \
       --module worker --config-file=/etc/cube/cube.conf \
       --log-file=/var/log/cube/worker.log
    [ $? != 0 ] && logger error "cube-worker not be created!" && exit 1

    sleep 1
    docker ps
}

start_cube19091()
{
    #Start 3 docker:cube-api-19091/cube-controller-19091/cube-work-19091,which service port is 19091
    if [ -z "$1" ];then
        dis_usage
        exit 1
    fi
    #VERSION="20181120_release"
    VERSION=$1
    DOCKER_HUB="dockerhub.nie.netease.com"
    mkdir -p /home/cld/log/cube

    netstat -an |awk '{print $4}'|grep "0.0.0.0:19091" >/dev/null >/dev/null
    cube19091_port_exist_flag=$(echo $?)


    if [  ${cube19091_port_exist_flag} == 0  ];then
        #if cube-api-19091 is already running,raise error.
        logger error "Error,cube-api-19091 is already running,pls check docker status."
        exit 1
    fi
    logger info "docker run cube-api-19091"
    docker run -d --name=cube-api-19091 --net=host \
       -v /home/cld/log/cube/:/var/log/cube/ \
       -v ${CONFIGDIR}/cube19091.conf:/etc/cube/cube.conf \
       $DOCKER_HUB/skyline-cld/cld-api-server:$VERSION \
       --module api --config-file=/etc/cube/cube.conf \
       --log-file=/var/log/cube/api.log
    [ $? != 0 ] && logger error "cube-api-19091 not be created!" \
       && docker rename cube-api-old cube-api \
       && docker rename cube-worker-old cube-worker \
       && docker rename cube-controller-old cube-controller \
       && exit 1

    logger info "docker run cube-controller-19091"
    docker run -d --name=cube-controller-19091 --net=host \
       -v /home/cld/log/cube/:/var/log/cube/ \
       -v ${CONFIGDIR}/cube19091.conf:/etc/cube/cube.conf \
       $DOCKER_HUB/skyline-cld/cld-api-server:$VERSION \
       --module controller --config-file=/etc/cube/cube.conf \
       --log-file=/var/log/cube/controller.log
    [ $? != 0 ] && logger error "cube-controller-19091 not be created!" && exit 1

    logger info "docker run cube-worker-19091"
    docker run -d --name=cube-worker-19091 --net=host \
       -v /home/cld/log/cube/:/var/log/cube/ \
       -v ${CONFIGDIR}/cube19091.conf:/etc/cube/cube.conf \
       $DOCKER_HUB/skyline-cld/cld-api-server:$VERSION \
       --module worker --config-file=/etc/cube/cube.conf \
       --log-file=/var/log/cube/worker.log
    [ $? != 0 ] && logger error "cube-worker-19091 not be created!" && exit 1

}


start_new_cube()
{

    docker ps -a |grep "old" >/dev/null
    [ $? == 0 ] && logger error "Already dcoker name is cube-xxx-old,CANNT docker rename." && exit 1

    netstat -an |awk '{print $4}'|grep "0.0.0.0:19090" >/dev/null
    cube_port_exist_flag=$?

    netstat -an |awk '{print $4}'|grep "0.0.0.0:19091" >/dev/null
    cube19091_port_exist_flag=$?

    if [ ${cube_port_exist_flag} == 0 -a "${cube19091_port_exist_flag}" == "0" ];then
        logger Error "Error,already two cube instance running,pls check!"
        exit 1
    elif [  ${cube19091_port_exist_flag} == 0 ];then
        #cube-api-19091 is running and 19091 is exist,so start cube-api
        #docker rename,if need

        for j in `docker ps |grep cube|awk '{print $NF}'`
        do
            if [ $j == "cube-api" ];then
            docker rename cube-api cube-api-old
            logger info "docker rename cube-api cube-api-old"
            fi
            if [ $j == "cube-controller"  ];then
                docker rename cube-controller cube-controller-old
                logger info "docker rename cube-controller cube-controller-old"
            fi
            if [ $j == "cube-worker"  ];then
                docker rename cube-worker cube-worker-old
                logger info "docker rename cube-worker cube-worker-old"
            fi
        done
        start_cube19090 $1
    elif [ ${cube_port_exist_flag} == 0 ];then
        #cube-api is running and 19090 is exist,so start cube-api-19091
        for j in `docker ps |grep cube|awk '{print $NF}'`
        do
            if [ $j == "cube-api" ];then
            docker rename cube-api cube-api-old
            logger info "docker rename cube-api cube-api-old"
            fi
            if [ $j == "cube-controller"  ];then
                docker rename cube-controller cube-controller-old
               logger info "docker rename cube-controller cube-controller-old"
            fi
            if [ $j == "cube-worker"  ];then
                docker rename cube-worker cube-worker-old
                logger info "docker rename cube-worker cube-worker-old"
            fi
        done

        start_cube19091 $1

        for j in `docker ps |grep cube|awk '{print $NF}'`
        do
            if [ $j == "cube-api-19091" ];then
                docker rename cube-api-19091 cube-api
                logger info "docker rename cube-api-19091 cube-api"
            fi
            if [ $j == "cube-controller-19091"  ];then
                docker rename cube-controller-19091 cube-controller
                logger info "docker rename cube-controller-19091 cube-controller"
            fi
            if [ $j == "cube-worker-19091"  ];then
                docker rename cube-worker-19091 cube-worker
                logger info "docker rename cube-worker-19091 cube-worker"
            fi
        done
        sleep 1
        docker ps
    else
        logger error "Error,pls check docker status."
        exit 1
    fi
}


rm_no_use_cube()
{
    if [ $(docker ps |awk  /cube/'{print $2}'|grep -o "[0-9]\{8\}"|sort -n|uniq |wc -l) != 2 ];then
        logger error "Error,only one cube instance running."
        exit 1
    fi
#    VERSION01=`docker ps |awk  /cube/'{print $2}'|grep -o "[0-9]\{8\}"|sort -n|uniq |head -1`
#    VERSION02=`docker ps |awk  /cube/'{print $2}'|grep -o "[0-9]\{8\}"|sort -n|uniq |tail -1`
#    OLDVERSION=
#    if [ ${VERSION01} == "" -o ${VERSION02} == "" ];then
#        logger error "Error,pls check wich \"docker ps\""
#        exit 1
#    fi
#
#    #get old version of cube release
#    if [ "${VERSION01}" -lt "${VERSION02}" ];then
#        OLDVERSION=${VERSION01}
#    else
#        OLDVERSION=${VERSION02}
#    fi
#
#    #check cube version which LBC put traffic to
#    get_cube_version
#    read -p "LBC已经将流量转发到该版本,确定删除old version实例,请输入"Y":" ans
#    if [ ${ans} == "Y" -o ${ans} == "y"  -o ${ans} == "yes" -o ${ans} == "YES" ];then
#        logger warnning "rm old version docker......"
#     else
#        logger warnning "You choose not to rm old version docker,exit."
#        exit
#    fi

    #rm docker-ps of old version
    for i in `docker ps |grep old|awk '{print $NF}'`
    do
        docker stop $i >/dev/null
        docker rm $i >/dev/null
        logger warnning "docker rm $i"
        [ $? != 0 ] && logger error "docker rm $i,is false.pls check."
    done

    #docker rename,if need
    for j in `docker ps |grep cube|awk '{print $NF}'`
    do
        if [ $j == "cube-api-19091" ];then
            docker rename cube-api-19091 cube-api
            logger info "docker rename cube-api-19091 cube-api"
        fi
        if [ $j == "cube-controller-19091"  ];then
            docker rename cube-controller-19091 cube-controller
            logger info "docker rename cube-controller-19091 cube-controller"
        fi
        if [ $j == "cube-worker-19091"  ];then
            docker rename cube-worker-19091 cube-worker
            logger info "docker rename cube-worker-19091 cube-worker"
        fi
    done
    sleep 1 && docker ps
}


rm_desinated_cube()
{
    version=$1
    #根据输入的版本号,判断是否运行中docker存在该版本
    flag=0
    for i in `docker ps |awk /cube/'{print $2}'|awk -F: '{print $NF}'|uniq`
    do
        [ $i == ${version} ] && flag=1
    done
    [ ${flag} != 1 ] && logger error "Input version is error." && exit 1


    read -p "确定删除${version}对应的cube实例,请输入"Y":" ans
    if [ ${ans} == "Y" -o ${ans} == "y"  -o ${ans} == "yes" -o ${ans} == "YES" ];then
        logger warnning "rm dockers of version:${version} ......"
     else
        logger warnning "You choose not to rm old version docker,exit."
        exit 0
    fi
    for i in `docker ps |grep ${version}|awk /cube-/'{print $NF}'`
    do
        logger warnning "docker rm $i"
        docker stop $i >/dev/null
        docker rm $i >/dev/null
        [ $? != 0 ] && logger error "docker rm $i,is false.pls check."
    done
    sleep 1 && docker ps
}



#Option deal with
if [ -z "$1" ];then
    dis_usage
    exit 1
fi
if [ "$1" != "-d" -a "$1" != "-u" -a "$1" != "-h"  -a "$1" != "-g" -a "$1" != "-r" ];then
    logger error "Options is Error!"
    dis_usage
    exit 1
fi

TEMP=`getopt -o ghdu:r: -n 'Error' -- "$@"`
#echo '$TEMP' $TEMP
eval set -- "$TEMP"


while [ ! -z $1 ]
do
    case "$1" in
        -h)
            ##help display
            dis_usage
            shift
            ;;
        -d)
            ##delete old version cube
            rm_no_use_cube
            shift
            ;;
         -g)
            ##get cube version of LBC effective
            get_cube_version
            shift
            ;;
        -u)
            ##update version
            start_new_cube $2
            shift 2
            ;;
        -r)
            ##rm designated docker which you wish
            rm_desinated_cube $2
            shift 2
            ;;
        *)
            break ;;
    esac
done
exit 0