#!/bin/sh
# init cld user and init cbcx

echo "Adding game users..."
game_adduser(){
    user="$1"
    public_key="$2"

    if id "$user" >/dev/null 2>&1
    then
        echo "User $user exist"
        /usr/sbin/usermod -u 10000 -c $user $user
    else
        if grep -q "^$user:" /etc/group
        then
            groupdel "$user"
        fi
        /usr/sbin/useradd -u 10000 -c "$user" -m "$user"
    fi

    mkdir -p /home/${user}/.ssh /home/${user}/cbrc /home/${user}/log /home/${user}/conf
    echo "$public_key" >/home/${user}/.ssh/authorized_keys

    chmod 755 /home/${user}/.ssh
    chmod 600 /home/${user}/.ssh/authorized_keys

    chown -R ${user}:${user} /home/${user} && \
    /usr/sbin/usermod -p '*' -s /bin/bash $user && \
    /usr/sbin/usermod -U $user

    echo "Adding $user successfully"
}

game_adduser cld 'command="PYTHONPATH=/home/cld/cbrc/ cbrc" ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC37OlHoX4+Wm+AjUqt5DeACuurRZ3qzNKXRIc8mxkDAMG3BwtcK4MTBUY7+mz+LOde4UXeS/cQS3ccnc3jvMcO7g5XcsC8sHDXLPEK2q45JRVdbA4P3jM48Lcla3PqY171BtO6H6xZN5cbcICPLY+Pl/vcHQCPJkyZw8ccf72UGaaef0lemv4q8CS+2c8Q/johagVK6SvLvWzuY1dB6/iyqmS6nG9+hu1wFPOoKFTKnQ6cJpGc8/+4Exo1R9tPCsImU7KPphKq/h/JMeMZXu8ExJqEnF1Xlc4kShepgFSLduyMTxS9jXnjIT/8uhK6+htFqiu9VEhAwDl/JhwnZ2Nx cld@cld-admin'

exter_interface=`/sbin/route -n | awk '$1~/0.0.0.0/ && $0~/UG/{print $NF}'`
if /sbin/ifconfig "$exter_interface" | egrep 'addr:192.168|addr:10.246|addr:10.62'
then
    rsync_server='192.168.10.195'
else
    rsync_server='10.120.173.213'
fi
rsync -av -L --port 8873 --exclude '.svn' --exclude '*.pyc' --delete-after ${rsync_server}::output/cbrc/ /home/cld/cbrc/

aptitude install python-pip python-lxml
pip uninstall cbcx
pip uninstall cbc3
pip install trollius -i https://pip.nie.netease.com/simple --trusted-host pip.x.netease.com
pip install cbc3 -i https://pip.nie.netease.com/simple --trusted-host pip.x.netease.com
