#!/usr/bin/env bash

# create net device net-stor
# create net device net-stor
if [ $(virsh net-list --all |grep net-stor|wc -l) == 0 ];then
    touch net-stor.xml
    cat << eof > net-stor.xml
<network >
  <name>net-stor</name>
  <forward mode='hostdev' managed='yes'>
    <driver name='vfio'/>
    <pf dev='eth3'/>
  </forward>
</network>
eof
   virsh net-define net-stor.xml
   [ $? != 0 ] && exit 1
   virsh net-start net-stor
   [ $? != 0 ] && exit 1
   virsh net-autostart net-stor
   [ $? != 0 ] && exit 1

   echo "net-stor have added."
else
   echo "already have net-stor"
fi

# change xml for nfvi

matchion_xml=$1
virsh dumpxml  ${matchion_xml} > matchion_xml.xml


linenum=$(cat cld-nfvi1-58.xml |grep -n '</interface>' |tail -1  )

   sed '${linenum} i <interface type=\'network\'> ' ${matchion_xml}.xml
   let linenum=${linenum} + 1
   sed '${linenum} i <source network=\'net-stor\'/> ' ${matchion_xml}.xml
   let linenum=${linenum} + 1
      <model type='rtl8139'/>
    </interface>
done
