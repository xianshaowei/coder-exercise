#! /bin/sh
#
# Author: Linghua Zeng <gzzenglinghua@corp.netease.com>
# Filename: initpuppet.sh
# Last modified: 2014-11-20
# Version:1.5

# Global variables for Debian and FreeBSD
VER="1000"
PKGURL="http://puppet.x.netease.com/installpp"
FLAGDIR=/var/init
INITLOG=$FLAGDIR/init.log
BAKDIR=$FLAGDIR/backup
CHANGELIST="hosts resolv.conf"
DNSSERVER1='106.2.69.77'
DNSSERVER2='123.125.48.205'
AWSDNSSERVER1='13.228.9.36'
AWSDNSSERVER2='54.199.241.182'
FOREIGNDNSSERVER="54.199.241.182
13.228.9.36
50.112.80.29"
PUPPETMASTER='puppet.x.netease.com'
BRANCH='production'
PUPPET_VER='3.4.3'
START_PUPPET='yes'
SSL_CGI='http://puppet.x.netease.com:8000/cgi-bin/certmgr.py?ip='
AWS=0
SET_INNER_IP='no'

# Global variables for Debian
LENNY_APT_SOURCE="deb http://apt.x.netease.com:8660/debian-archive/debian/ lenny main non-free contrib"
SQUEEZE_APT_SOURCE="deb http://apt.x.netease.com:8660/debian-archive/debian/ squeeze main non-free contrib"
SQUEEZE_APT_SOURCE2="deb-src http://apt.x.netease.com:8660/debian-archive/debian/ squeeze main non-free contrib"
SQUEEZE_APT_SOURCE3="deb http://sa.apt.netease.com:8660/debian/ squeeze main"
WHEEZY_APT_SOURCE="deb http://apt.x.netease.com:8660/debian/ wheezy main non-free contrib"
WHEEZY_APT_SOURCE2="deb http://apt.x.netease.com:8660/debian/ wheezy-updates main non-free contrib"
WHEEZY_APT_SOURCE3="deb http://apt.x.netease.com:8660/debian-security/ wheezy/updates main non-free contrib"
AWS_WHEEZY_APT_SOURCE="deb http://cloudfront.debian.net/debian wheezy main non-free contrib"
AWS_WHEEZY_APT_SOURCE2="deb http://security.debian.org/ wheezy/updates main non-free contrib"
AWS_WHEEZY_APT_SOURCE3="deb http://cloudfront.debian.net/debian wheezy-updates main non-free contrib"
JESSIE_APT_SOURCE="deb http://apt.x.netease.com:8660/debian/ jessie main non-free contrib"
JESSIE_APT_SOURCE2="deb http://apt.x.netease.com:8660/debian/ jessie-updates main non-free contrib"
JESSIE_APT_SOURCE3="deb http://apt.x.netease.com:8660/debian-security/ jessie/updates main non-free contrib"
AWS_JESSIE_APT_SOURCE="deb http://cloudfront.debian.net/debian jessie main non-free contrib"
AWS_JESSIE_APT_SOURCE2="deb http://security.debian.org/ jessie/updates main non-free contrib"
AWS_JESSIE_APT_SOURCE3="deb http://cloudfront.debian.net/debian jessie-updates main non-free contrib"
STRETCH_APT_SOURCE="deb http://apt.x.netease.com:8660/debian/ stretch main non-free contrib"
STRETCH_APT_SOURCE2="deb http://apt.x.netease.com:8660/debian/ stretch-updates main non-free contrib"
STRETCH_APT_SOURCE3="deb http://apt.x.netease.com:8660/debian-security/ stretch/updates main non-free contrib"
AWS_STRETCH_APT_SOURCE="deb http://cloudfront.debian.net/debian stretch main non-free contrib"
AWS_STRETCH_APT_SOURCE2="deb http://security.debian.org/ stretch/updates main non-free contrib"
AWS_STRETCH_APT_SOURCE3="deb http://cloudfront.debian.net/debian stretch-updates main non-free contrib"
APT_SOURCE_FILE="/etc/apt/sources.list"

# funcs
help()
{
        cat <<_EOF
Usage:
    $0 [-h]
    $0 [-v <puppet_version>] [-b <devel|testing|production>] [-s <yes|no>] [-i <yes|no>]
    $0 [-r]

    -v : 指定要安装的puppet版本，默认为3.4.3
    -b : 指定使用的分支，可选值为devel|testing|production，默认为production
    -s : 选择安装完后是否启动puppet,可选值为yes|no，默认值为yes
    -i : 指定是否设置内网ip,可选值为yes|no,默认为no

    -r : 恢复备份的配置文件
    -d : 卸载puppet-3.4.3

    -h : 打印命令帮助信息
_EOF
    exit 0
}

check_apt()
{
    if [ `which apt-get` ];then
        APT_CMD="apt-get"
    elif [ `which aptitude` ];then
        APT_CMD="aptitude"
    fi
}

check_user()
{
    local user=$1
    local IAM=`whoami`
    if [ "$IAM" != "$user" ];then
        errmsg "$0 must run by $user"
        exit 1
    fi
}

errmsg()
{
    local msg="$@"
    echo "ERROR: $msg" | tee -a $INITLOG
}

backup()
{
    if [ -d $BAKDIR ] ; then
        mv $BAKDIR $BAKDIR.$(date +"%s")
    fi

    mkdir -p $BAKDIR
    check_error $? 1 "failed to mkdir $BAKDIR"

    for f in $CHANGELIST
    do
        if [ -f /etc/$f ] ; then
            cp -p /etc/$f $BAKDIR/
            check_error $? 1 "failed to cp /etc/$f $BAKDIR/"
        fi
    done
}

restore()
{
    for f in $CHANGELIST
    do
        if [ -f $BAKDIR/$(basename $f) ] ; then
            cp -p $BAKDIR/$(basename $f) /etc/$f
            check_error $? 1 "failed to resotre $f"
        else
            errmsg "no backup of $f found"
        fi
    done
}

# check status of a cmd, print error info
check_error()
{
    ret=$1
    msg=$2

    if [ "$ret" != "0" ]; then
        echo $msg
        exit 1
    fi
}

# check version of OS
check_os_version_debian ()
{
    if [ "`uname -s`" = "Linux" ]; then
        if ! grep -q "^[0-9]" /etc/debian_version
        then
            echo "Please set debian version as digit format in /etc/debian_version!!!" &&  exit 1
        fi

        ver=`cat /etc/debian_version |cut -d'.' -f1`
        if [ $ver -ne 5 -a $ver -ne 6 -a $ver -ne 7 -a $ver -ne 8 -a $ver -ne 9 ]; then
            echo "not support version $ver" && exit 1
        fi
    fi
}

# check whether it is root usr
check_root()
{
    if [ "`whoami`" != "root" ]; then
        echo "Should run in root"
        exit 1
    fi
}

# check download command
check_getcmd()
{
    OS=`uname -s`

    if [ "$OS" = "FreeBSD" ]; then
        GETCMD="fetch"
    elif [ "$OS" = "Linux" ]; then
        GETCMD="wget"
    else
        echo "Not support this os" && exit 1
    fi
}

httpget()
{
    local url="$1"
    local dst="$2"

    OS=`uname -s`
    if [ "$OS" = "FreeBSD" ] ; then
        fetch -q -o $dst "$url"
    else
        wget -q -O $dst "$url"
    fi

    check_error $? "ERROR: Failed to get $url"
}

check_update()
{
    tmpver="/tmp/ver.pp3"
    httpget "$PKGURL/ver.pp3" $tmpver
    curver="$(cat $tmpver)"
    if [ "$curver" = "" ] ; then
        echo 'ERROR: Failed to get update, try again'
        rm $tmpver
        exit 1
    fi
    if [ "$curver" != "$VER" ] ; then
        echo "INFO: NEW VERSION $curver is available, try to update myself ..."
        httpget "$PKGURL/initpuppet.sh" "$0"
        echo "INFO: Update done. Please run me AGAIN !!!"
        rm $tmpver
        exit 1
    fi
}

get_myip_debian()
{
    if [ x"$AWS" = 'x1' ]; then
        myip=`wget -O - -q http://169.254.169.254/latest/meta-data/public-ipv4`
        if [ ! -n "$myip" ];then
            device=`netstat -rn | awk '{ if ( $1 == "0.0.0.0" ) print $8 }'`
            if [ "$device" ]; then
                if [ "x$device" = "x*" ]; then
                    device=`ifconfig | head -1 | awk '{print $1}'`
                    check_error $? 'Get ip failed ...'
                fi
                myip=`ip addr show $device | awk '{ if ( $1 == "inet" ) { split($2, token, "/") ; print token[1] } }' | head -1`
                inner_ip=`ip addr show $device | awk '{ if ( $1 == "inet" ) { split($2, token, "/") ; print token[1] } }' | head -1`
                if [ "$myip" ]; then
                    echo $myip
                fi
            fi
        else
            echo $myip
            device=`netstat -rn | awk '{ if ( $1 == "0.0.0.0" ) print $8 }'`
            if [ "$device" ]; then
                if [ "x$device" = "x*" ]; then
                    device=`ifconfig | head -1 | awk '{print $1}'`
                    check_error $? 'Get ip failed ...'
                fi
                inner_ip=`ifconfig $device | awk '{ if ( $1 == "inet" ) { split($2, token, ":") ; print token[2] } }' | head -1`
            fi
        fi
    else
        device=`netstat -rn | awk '{ if ( $1 == "0.0.0.0" ) print $8 }'`
        if [ "$device" ]; then
            if [ "x$device" = "x*" ]; then
                device=`ifconfig | head -1 | awk '{print $1}'`
                check_error $? 'Get ip failed ...'
            fi
            debianver=`cat /etc/debian_version| cut -d '.' -f1`
            if [ "x$debianver" = "x9" ];then
                #myip=`ifconfig $device | awk '{ if ( $1 == "inet" ) { split($2, token, " ") ; print token[1] } }'|awk -F ":" '{print $2}'`
                myip=`ip route get 1 | awk '{print $NF;exit}'`
            else
                myip=`ifconfig $device | awk '{ if ( $1 == "inet" ) { split($2, token, ":") ; print token[2] } }' | head -1`
            fi
            if [ "$myip" ]; then
                echo $myip
            fi
        fi
    fi
}

get_architecture_debian () {
    arch=`uname -m`
    case ${arch} in
        i*)
            architecture='i386'
            ;;
        *)
            architecture='amd64'
            ;;
    esac
    echo $architecture
}

# 下载puppet lib
get_lib()
{
    mkdir -p /var/lib/puppet && cd /var/lib/puppet
    check_error $? "mkdir /var/lib/puppet failed"

    if [ "`uname -s`" = "FreeBSD" ]; then
        fetch -o puppetlib.tar "$PKGURL/$PUPPET_VER/puppetlib.tar" && tar -xf puppetlib.tar && rm -f puppetlib.tar
    else
        wget -O puppetlib.tar "$PKGURL/$PUPPET_VER/puppetlib.tar" && tar -xf puppetlib.tar && rm -f puppetlib.tar
    fi
}

get_osver_from_galaxy() {
    wget -O /tmp/getver.py "http://puppet.x.netease.com/installpp/scripts/getver.py"
    if [ $? -ne 0 ]; then
        return 'None'
    fi
    export MYIP=${myip}
    os_version=`python /tmp/getver.py`
}

get_snapshot_gpg() {
    gpgdir='/etc/apt/trusted.gpg.d'
    gpgfile="$gpgdir/nie-snapshot.gpg"
    if [ ! -d $gpgdir ];then
        mkdir -p $gpgdir
    fi
    if [ ! -f $gpgfile ];then
        wget -O $gpgfile "http://puppet.x.netease.com/installpp/gpg/nie-snapshot.gpg"
        if [ $? -ne 0 ]; then
            echo 'Can not get gpg file for snapshot source list.'
            exit 1
        fi
    fi
}

set_apt_source() {
    if [ "x${AWS}" = "x1" ]; then
        $APT_CMD update
        return
    fi
    debianver=`cat /etc/debian_version`
    case $debianver in
        5.*)
            echo $LENNY_APT_SOURCE > $APT_SOURCE_FILE && $APT_CMD update
            dpkg -l | grep -w 'libssl0.9.8' | grep "^i" || $APT_CMD install -yy libssl0.9.8
            check_error $? 'install libssl0.9.8 fail'
            ;;
        6.*)
            echo $SQUEEZE_APT_SOURCE > $APT_SOURCE_FILE
            echo $SQUEEZE_APT_SOURCE2 >> $APT_SOURCE_FILE
            echo $SQUEEZE_APT_SOURCE3 >> $APT_SOURCE_FILE
            $APT_CMD update
            dpkg -l | grep -w 'libssl0.9.8' | grep "^i" || $APT_CMD install -yy libssl0.9.8
            check_error $? 'install libssl0.9.8 fail'
            ;;
        7.*)
            if [ "x${AWS}" = "x1" ]; then
                echo $AWS_WHEEZY_APT_SOURCE > $APT_SOURCE_FILE
                echo $AWS_WHEEZY_APT_SOURCE2 > $APT_SOURCE_FILE
                echo $AWS_WHEEZY_APT_SOURCE3 > $APT_SOURCE_FILE
            else
                echo $WHEEZY_APT_SOURCE > $APT_SOURCE_FILE
                echo $WHEEZY_APT_SOURCE2 >> $APT_SOURCE_FILE
                echo $WHEEZY_APT_SOURCE3 >> $APT_SOURCE_FILE
            fi
            $APT_CMD update
            dpkg -l | grep -w 'libssl1.0.0' | grep "^i" || $APT_CMD install -yy libssl1.0.0
            check_error $? 'install libssl1.0.0 fail'
            ;;
        8.*)
            get_osver_from_galaxy
            if [ "$os_version" = 'None' ]; then
                if [ "x${AWS}" = "x1" ]; then
                    echo $AWS_JESSIE_APT_SOURCE > $APT_SOURCE_FILE
                    echo $AWS_JESSIE_APT_SOURCE2 >> $APT_SOURCE_FILE
                    echo $AWS_JESSIE_APT_SOURCE3 >> $APT_SOURCE_FILE
                else
                    echo $JESSIE_APT_SOURCE > $APT_SOURCE_FILE
                    echo $JESSIE_APT_SOURCE2 >> $APT_SOURCE_FILE
                    echo $JESSIE_APT_SOURCE3 >> $APT_SOURCE_FILE
                fi
            else
                get_snapshot_gpg
                echo "deb http://snapshot.apt.netease.com:8660/debian${os_version} jessie main non-free contrib" > $APT_SOURCE_FILE
                echo "deb-src http://snapshot.apt.netease.com:8660/debian${os_version} jessie main non-free contrib" >> $APT_SOURCE_FILE
                echo "deb http://sa.apt.netease.com:8660/debian/ jessie main" >> $APT_SOURCE_FILE
            fi
            $APT_CMD update
            dpkg -l | grep -w 'libssl1.0.0' | grep "^i" || $APT_CMD install -yy libssl1.0.0
            check_error $? 'install libssl1.0.0 fail'
            ;;
        9.*)
            get_osver_from_galaxy
            if [ "$os_version" = 'None' ]; then
                if [ "x${AWS}" = "x1" ]; then
                    echo $AWS_STRETCH_APT_SOURCE > $APT_SOURCE_FILE
                    echo $AWS_STRETCH_APT_SOURCE2 >> $APT_SOURCE_FILE
                    echo $AWS_STRETCH_APT_SOURCE3 >> $APT_SOURCE_FILE
                else
                    echo $STRETCH_APT_SOURCE > $APT_SOURCE_FILE
                    echo $STRETCH_APT_SOURCE2 >> $APT_SOURCE_FILE
                    echo $STRETCH_APT_SOURCE3 >> $APT_SOURCE_FILE
                fi
            else
                get_snapshot_gpg
                echo "deb http://snapshot.apt.netease.com:8660/debian${os_version} stretch main non-free contrib" > $APT_SOURCE_FILE
                echo "deb-src http://snapshot.apt.netease.com:8660/debian${os_version} stretch main non-free contrib" >> $APT_SOURCE_FILE
                echo "deb http://sa.apt.netease.com:8660/debian/ stretch main" >> $APT_SOURCE_FILE
            fi
            $APT_CMD update
            dpkg -l | grep -w 'libssl1.1' | grep "^i" || $APT_CMD install -yy libssl1.1
            check_error $? 'install libssl1.1 fail'
            ;;
        default)
            ;;
    esac

    # 安装lsb-release，lsb相关的fact会依赖这个包
    dpkg -l | grep -w 'lsb-release' | grep "^i" || $APT_CMD install -yy lsb-release
}

init_dns_debian() {
    $APT_CMD -yy --force-yes install dnsutils > /dev/null
    if [ x"$AWS" = 'x1' -a `echo $inner_ip|grep -c ^"10.74."` -ne 1 ]; then
        if [ -n $AWSDNSSERVER1 ]; then
            echo "nameserver $AWSDNSSERVER1" >> /etc/resolv.conf
        fi
        if [ -n $AWSDNSSERVER2 ]; then
            echo "nameserver $AWSDNSSERVER2" >> /etc/resolv.conf
        fi
    fi
}

init_hostname_debian () {
#    myip=`get_myip_debian`
    $APT_CMD -yy --force-yes install dig > /dev/null
    if [ ! -e /usr/bin/host ];then
        DEBIAN_FRONTEND=noninteractive $APT_CMD --force-yes -fuy install dnsutils
    fi

    if [ x"$AWS" = 'x1' -a `echo $inner_ip|grep -c ^"10.74."` -ne 1 ]; then
        dnsserver=$AWSDNSSERVER1
    else
        dnsserver=$DNSSERVER1
    fi
    result=`dig +time=3 +tcp @${dnsserver} -x $myip | grep -A 1 ANSWER|tail -1`
    if [ -z "$result" ]; then
        for _dnsserver in $FOREIGNDNSSERVER
        do
            result=`dig +time=3 +tcp @${_dnsserver} -x $myip | grep -A 1 ANSWER|tail -1`
            if [ "x$?" = "x9" ]; then
                echo "ERROR: The dns server $_dnsserver is unreachable"
            fi
            if [ ! -z "$result" ];then
                break
            fi
        done
    fi
    if [ -z "$result" ]; then
        echo "ERROR: The IP $myip is not registered in DNS server."
        exit 1
    fi

    newhostname=`echo $result | awk '{print $5}' | cut -d'.' -f1`
    check_error $? 'get hostname fail'
    domainname='i.nease.net'
    cat /etc/hosts | grep "puppet.x.netease.com" >> /dev/null
    if [ $? -ne 0 -a x"$AWS" = 'x1' -a `echo $inner_ip|grep -c ^"10.74."` -ne 1 ]; then
        cat <<_EOF >> /etc/hosts
52.192.19.77            puppet.x.netease.com
_EOF
    fi
    debianver=`cat /etc/debian_version| cut -d '.' -f1`
    if [ "x$debianver" = "x9" ];then
        apt-get install -yy dbus 
        echo "$newhostname.$domainname" > /etc/hostname && hostnamectl set-hostname $newhostname.$domainname
    else
        echo "$newhostname.$domainname" > /etc/hostname &&  /etc/init.d/hostname.sh
    fi
    check_error $? 'set hostname fail'
}

rm_old_puppet_debian() {
    if [ `dpkg -l|grep -cw puppetmaster` -ge 1 ];then
        $APT_CMD purge -y puppetmaster > /dev/null && $APT_CMD purge -y puppetmaster-common > /dev/null
        check_error $? 'Purge puppetmaster fail'
    fi
    if [ `dpkg -l|grep -cw puppet` -ge 1 ];then
        $APT_CMD purge -y puppet > /dev/null && $APT_CMD purge -y puppet-common > /dev/null
        check_error $? 'Purge puppet fail'
    fi

    rm -rf /var/lib/puppet/clientbucket/
    hash /usr/local/bin/puppet puppet
}

check_puppet_user_debian() {
    if ! getent passwd puppet > /dev/null; then
        adduser --system --quiet --group \
            --home /home/puppet --shell /bin/bash \
            puppet
    elif [ ! -d '/home/puppet' ];then
        /usr/sbin/userdel -r puppet
        adduser --system --quiet --group \
            --home /home/puppet --shell /bin/bash \
            puppet
    fi
    check_error $? 'Check puppet user fail'
}

install_pip_debian() {
    $APT_CMD install -y python-pip
    if [ `which easy_install` ];then
        easy_install -i https://pip.nie.netease.com/simple pip==8.1.1
    fi
}

install_systemd_debian() {
    if `dpkg -l|grep -w sysvinit-core|grep -qv ^ii`;then
        if [ -d "/run/systemd/system" -a ! -L "/sbin/init" ] ;then
            $APT_CMD install -y systemd-sysv
        fi
    fi
}


init_puppet_debian () {
    # 确保/usr/local/bin和/usr/local/sbin目录存在
    mkdir -p /usr/local/bin && mkdir -p /usr/local/sbin

    architecture=`get_architecture_debian`
    debian_version=`cat /etc/debian_version`
    case ${debian_version} in
        5.0*)
            pkgname="puppetall_${PUPPET_VER}-1lenny1_${architecture}.deb"
            wget -O /tmp/$pkgname $PKGURL/${PUPPET_VER}/$pkgname
            check_error $? "Download pkg $pkgname fail"
            dpkg -i /tmp/$pkgname
            check_error $? "Install pkg $pkgname fail"
            ;;
        6.0*)
            pkgname="puppetall_${PUPPET_VER}-1squeeze1_${architecture}.deb"
            wget -O /tmp/$pkgname $PKGURL/${PUPPET_VER}/$pkgname
            check_error $? "Download pkg $pkgname fail"
            dpkg -i /tmp/$pkgname
            check_error $? "Install pkg $pkgname fail"
            ;;
        7.*)
            pkgname="puppetall_${PUPPET_VER}-1wheezy1_${architecture}.deb"
            wget -O /tmp/$pkgname $PKGURL/${PUPPET_VER}/$pkgname
            check_error $? "Download pkg $pkgname fail"
            dpkg -i /tmp/$pkgname
            check_error $? "Install pkg $pkgname fail"
            ;;
        8.*)
            pkgname="puppetall_${PUPPET_VER}-1jessie1_${architecture}.deb"
            wget -O /tmp/$pkgname $PKGURL/${PUPPET_VER}/$pkgname
            check_error $? "Download pkg $pkgname fail"
            dpkg -i /tmp/$pkgname
            check_error $? "Install pkg $pkgname fail"
            ;;
        9.*)
            pkgname="puppetall_${PUPPET_VER}-1stretch1_${architecture}.deb"
            wget -O /tmp/$pkgname $PKGURL/${PUPPET_VER}/$pkgname
            check_error $? "Download pkg $pkgname fail"
            dpkg -i /tmp/$pkgname
            check_error $? "Install pkg $pkgname fail"
            ;;
    esac

    # 设置branch，可选值为devel|testing|production
    if [ "x$BRANCH" != "xdevel" -a "x$BRANCH" != "xtesting" -a "x$BRANCH" != "xproduction" ]; then
        echo "Branch input '$BRANCH' is invalid, use 'production' as default."
        BRANCH='production'
    fi
    sed -i "s/^environment.*/environment = $BRANCH/g" /etc/puppet/puppet.conf

    # 设置certname，将localhostname替换成`hostname`，避免首次运行时由于puppet.conf更新导致重启
    certname=`hostname`
    sed -i "s/localhostname/$certname/g" /etc/puppet/puppet.conf

    # 证书处理，删除旧证书
#    myip=`get_myip_debian`
    wget -O /dev/null $SSL_CGI$myip 2>/dev/null && rm -rf /var/lib/puppet/ssl
    check_error $? "Remove old cert failed !!!"

    # patch puppet
    if [ "x$ver" = "x9" ];then
        rubyver='2.4.0'
    else
        rubyver='1.8'
    fi
    wget -O /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/$rubyver/facter/projectname.rb $PKGURL/facter/projectname.rb 2>/dev/null
    check_error $? "Download projectname.rb failed !!!"
    GCE=`/usr/local/bin/facter virtual`
    if [ x"$AWS" = 'x1' ]; then
        wget -O /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/$rubyver/facter/ipaddress.rb $PKGURL/facter/ipaddress.rb.ec2 2>/dev/null
        check_error $? "Download ipaddress.rb.ec2 failed !!!"
    elif [ x"$GCE" = 'xgce' ];then
        wget -O /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/$rubyver/facter/ipaddress.rb $PKGURL/facter/ipaddress.rb.gce 2>/dev/null
        check_error $? "Download ipaddress.rb.gce failed !!!"
    fi
    wget -O /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/$rubyver/puppet/provider/package/pip.rb $PKGURL/src/pip.rb.${PUPPET_VER} 2>/dev/null
    check_error $? "Download pip.rb failed !!!"
    wget -O /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/$rubyver/puppet/provider/package/apt.rb $PKGURL/src/apt.rb.${PUPPET_VER} 2>/dev/null
    check_error $? "Download apt.rb failed !!!"
    wget -O /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/$rubyver/puppet/util/logging.rb $PKGURL/src/logging.rb 2>/dev/null
    check_error $? "Download logging.rb failed !!!"
    wget -O /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/$rubyver/puppet/util/error_notify.rb $PKGURL/src/error_notify.rb 2>/dev/null
    check_error $? "Download error_notify.rb failed !!!"

    # get lib
    #get_lib

    # 根据用户设置决定是否启动puppet
    if [ "x${START_PUPPET}" = "xyes" ]; then
        if [ "x${PUPPET_VER}" = "x3.4.3" ]; then
            echo "Starting puppet agent."
            /usr/local/bin/puppet agent -t > /dev/null 2>&1 &
        else
            /etc/init.d/puppet start
        fi
    else
        echo "As your choice, not start puppet now! You can run 'puppet agent -t' to start puppet."
    fi
}


get_ip_bsd()
{
    if [ x"$AWS" = 'x1' ]; then
        myip=`fetch -o - -q http://169.254.169.254/latest/meta-data/public-ipv4`
        echo $myip
        local netdev=`netstat -rn | grep default | awk '{print $6}' | tail -n 1`
        inner_ip=`/sbin/ifconfig $netdev | grep -w inet | awk '{print $2}' | head -n1`
    else
        local os_version=`uname -r|awk -F "." '{print $1}'`
        if [ x"$os_version" = 'x10' ];then
            local netdev=`netstat -rn | grep default | awk '{print $4}' | tail -n 1`
        else
            local netdev=`netstat -rn | grep default | awk '{print $6}' | tail -n 1`
        fi
        myip=`/sbin/ifconfig $netdev | grep -w inet | awk '{print $2}' | head -n1`
        inner_ip=`/sbin/ifconfig $netdev | grep -w inet | awk '{print $2}' | head -n1`
        if [ x"$myip" = 'x' ]; then
            netdevs="`/sbin/ifconfig |grep flags |cut -d':' -f1`"
            for dev in $netdevs ; do
                if [ x"$dev" = x"netdev" ]; then
                    continue
                else
                    myip=`/sbin/ifconfig $dev | grep -w inet | awk '{print $2}' | head -n1`
                    if [ x"$myip" != 'x' ]; then
                        break
                    fi
                fi
            done
        fi
        echo $myip
    fi
}

init_dns_bsd()
{
    if [ x"$AWS" = 'x1' -a `echo $inner_ip|grep -c ^"10.74."` -ne 1 ]; then
        if [ -n $AWSDNSSERVER1 ]; then
            echo "nameserver $AWSDNSSERVER1" >> /etc/resolv.conf
        fi
        if [ -n $AWSDNSSERVER2 ]; then
            echo "nameserver $AWSDNSSERVER2" >> /etc/resolv.conf
        fi
    else
        if [ -n $DNSSERVER1 ]; then
            echo "nameserver $DNSSERVER1" > /etc/resolv.conf
        fi
        if [ -n $DNSSERVER2 ]; then
            echo "nameserver $DNSSERVER2" >> /etc/resolv.conf
        fi
    fi
}

init_hostname_bsd () {

#    myip=`get_ip_bsd`
    if [ x"$AWS" = 'x1' -a `echo $inner_ip|grep -c ^"10.74."` -ne 1 ]; then
        dnsserver=$DNSSERVER1
    else
        dnsserver=$DNSSERVER1
    fi
    result=`host $myip`

    if [ `echo "$result"|grep -wc "not found"` -eq 1 ]; then
        echo "ERROR: The IP $myip is not registered in DNS server."
        exit 1
    fi
    
    newhostname=`echo $result | awk '{print $5}' | cut -d'.' -f1`
    check_error $? 'get hostname fail'
    domainname='i.nease.net'

    cat /etc/hosts | grep "puppet.x.netease.com" >> /dev/null
    if [ $? -ne 0 -a x"$AWS" = 'x1' -a `echo $inner_ip|grep -c ^"10.74."` -ne 1 ]; then
        cat <<_EOF >> /etc/hosts
52.192.19.77            puppet.x.netease.com
_EOF
    fi    

#    cat <<_EOF > /etc/hosts
#127.0.0.1               localhost.$domainname localhost
#$myip                   $newhostname.$domainname $newhostname
#$myip                   $newhostname.$domainname.
#_EOF

    hostname $newhostname.$domainname
    check_error $? 'set hostname fail'

    if [ -x /etc/rc.d/sendmail ]; then
        /etc/rc.d/sendmail onerestart
    fi
}

check_time_bsd() {
    # 安装puppet前先对时，防止时间不对导致证书错误
    if /etc/rc.d/ntpd status; then
        /etc/rc.d/ntpd stop && ntpdate ntp.x.netease.com && /etc/rc.d/ntpd start
    else
        ntpdate ntp.x.netease.com
    fi
}

# 设置pkgng配置文件
set_pkgng_bsd() {
    # set /etc/make.conf
    touch /etc/make.conf
    if ! grep "WITH_PKGNG=yes" /etc/make.conf
    then
        echo "WITH_PKGNG=yes" >> /etc/make.conf
    fi

    mkdir -p /usr/local/etc/pkg/repos
    # set /usr/local/etc/pkg.conf
    pkgconf=/usr/local/etc/pkg.conf
    if ! test -f $pkgconf
    then
        echo "PKG_DBDIR: /var/db/pkg" >> $pkgconf
        echo "PKG_CACHEDIR: /var/cache/pkg" >> $pkgconf
    fi

    # set /usr/local/etc/pkg/repos/{FreeBSD.conf NTES.conf}
    freebsdconf=/usr/local/etc/pkg/repos/FreeBSD.conf
    if ! test -f $freebsdconf
    then
        echo "FreeBSD: { enabled: no }" >> $freebsdconf
    fi
    ntesconf=/usr/local/etc/pkg/repos/NTES.conf
    if ! test -f $ntesconf
    then
        cat <<_EOF > $ntesconf
NTES: {
  url: "http://123.58.170.149:8000/\${ABI}",
  mirror_type: "HTTP",
  enabled: true,
}
_EOF
    fi

    # 执行pkg2ng
    if test -e /usr/local/sbin/pkg2ng
    then
        /usr/local/sbin/pkg2ng
    fi

    # 执行pkg update
    if test -e /usr/local/sbin/pkg
    then
        /usr/local/sbin/pkg update
    fi
}

install_pkg_bsd() {
    local os=`uname -s`
    if [ "x$os" = "xFreeBSD" ]; then
        local majver=`uname -r | awk -F"." '{print $1}'`
        local fulver=`uname -r | awk -F"-" '{print $1}'`

        set_pkgng_bsd
        # 从9开始，需要安装pkg
        if [ $majver -eq 9 -a ! -f /usr/local/sbin/pkg ]; then
            export ASSUME_ALWAYS_YES=YES
            /usr/sbin/pkg
            check_error $? "Install pkg failed ..."

        fi

        # 安装libiconv
        if ! pkg info | grep -q "libiconv-"
        then
            pkg install -y libiconv
            check_error $? "Install libiconv failed ..."
        fi
    fi
}

install_pip_bsd() {
    if [ `pip --version|grep -wc '8.1.1'` -ne 1 ];then
        pkg install -y py27-setuptools
        pkg install -y py27-pip
        pip install pip==8.1.1 -i https://pip.nie.netease.com/simple
    fi
}

init_puppet_bsd () {
    # 确保/usr/local/bin和/usr/local/sbin目录存在
    mkdir -p /usr/local/bin && mkdir -p /usr/local/sbin

    pkg install -y puppetall-3.4.3-1
    check_error $? 'Install pkg puppetall-3.4.3-1 fail, please contact administrator.'

    # 设置branch，可选值为devel|testing|production
    if [ "x$BRANCH" != "xdevel" -a "x$BRANCH" != "xtesting" -a "x$BRANCH" != "xproduction" ]; then
        echo "Branch input '$BRANCH' is invalid, use 'production' as default."
        BRANCH='production'
    fi
    sed -i'.bak' "s/environment.*/environment = $BRANCH/g" /etc/puppet/puppet.conf

    # 设置certname，将localhostname替换成`hostname`，避免首次运行时由于puppet.conf更新导致重启
    certname=`hostname`
    sed -i'.bak' "s/localhostname/$certname/g" /etc/puppet/puppet.conf

    # 证书处理，删除旧证书
#    myip=`get_ip_bsd`
    fetch -o /dev/null $SSL_CGI$myip 2>/dev/null && ([ ! -d '/var/lib/puppet/ssl' ] || rm -rf /var/lib/puppet/ssl)
    check_error $? "Remove old cert failed !!!"

    # patch puppet
    fetch -o /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/1.8/facter/projectname.rb $PKGURL/facter/projectname.rb 2>/dev/null
    check_error $? "Download projectname.rb failed !!!"
    if [ x"$AWS" = 'x1' ]; then
        fetch -o /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/1.8/facter/ipaddress.rb $PKGURL/facter/ipaddress.rb.ec2 2>/dev/null
        check_error $? "Download ipaddress.rb failed !!!"
    fi
    fetch -o /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/1.8/puppet/provider/package/pip.rb $PKGURL/src/pip.rb.${PUPPET_VER} 2>/dev/null
    check_error $? "Download pip.rb failed !!!"
    fetch -o /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/1.8/puppet/util/logging.rb $PKGURL/src/logging.rb 2>/dev/null
    check_error $? "Download logging.rb failed !!!"
    fetch -o /usr/local/puppetall-${PUPPET_VER}/lib/ruby/site_ruby/1.8/puppet/util/error_notify.rb $PKGURL/src/error_notify.rb 2>/dev/null
    check_error $? "Download error_notify.rb failed !!!"

    # get lib
    get_lib

    # 根据用户设置决定是否启动puppet
    if [ "x${START_PUPPET}" = "xyes" ]; then
        if [ "x${PUPPET_VER}" = "x3.4.3" ]; then
            echo "Starting puppet agent."
            /usr/local/bin/puppet agent -t > /dev/null 2>&1 &
        else
            /etc/rc.d/puppet start
        fi
    else
        echo "As your choice, not start puppet now! You can run 'puppet agent -t' to start puppet."
    fi
}

check_aws_debian () {
    wget -t1 -T1 -qO - 2>/dev/null http://169.254.169.254/latest/meta-data/placement/availability-zone|grep -vq kvm
    if [ $? -eq 0 ]; then
        AWS=1
    fi
}

check_aws_bsd () {
    fetch -T1 -q -o - http://169.254.169.254/latest/meta-data/placement/availability-zone 2> /dev/null |grep -vq kvm
    if [ $? -eq 0 ]; then
        AWS=1
    fi
}

# Debian系统设置内网ip
set_inner_ip_debian () {

    if [ "x${SET_INNER_IP}" = "xyes" ]; then
        wget -O /tmp/15instnetwork.sh "http://pub:xCW2quwz6OlRE@pub.x.netease.com:8001/init/archive/script/15instnetwork.sh"
        if [ $? -ne 0 ]; then
            echo "Get script for setting inner ip in Debian failed, please contact Puppet SA !!!" && return
        else
            bash /tmp/15instnetwork.sh
        fi
    fi
}

# FreeBSD系统设置内网ip
set_inner_ip_bsd () {

    if [ "x${SET_INNER_IP}" = "xyes" ]; then
        fetch -o /tmp/setip_inner_bsd.sh "http://puppet.x.netease.com/other/setip_inner_bsd.sh"
        if [ $? -ne 0 ]; then
            echo "Get script for setting inner ip in FreeBSD failed, please contact Puppet SA !!!" && return
        else
            sh /tmp/setip_inner_bsd.sh
        fi
    fi
}

# puppet 卸载
rm_puppet() {
os=`uname -s`
if [ $os = 'Linux' ]; then
    apt-get purge -y puppetall-3.4.3
    rm -rf /usr/local/puppetall-3.4.3 /var/lib/puppet
elif [ $os = 'FreeBSD' ]; then
    pkg_delete -f puppetall-3.4.3-1 
    pkg del -y puppetall-3.4.3-1
    rm -rf /usr/local/puppetall-3.4.3  
    rm -rf /var/lib/puppet
else
    echo "Not support os $os" && exit 1
fi
}

# 确保debian /etc/sysctl.conf 内容为空
init_sysctl_debian() {
    sysctl_info=`cat /etc/sysctl.conf`
    if [ -n "$sysctl_info" ];then
        > /etc/sysctl.conf
    fi
}

check_getcmd
check_update

# 处理用户输入参数
while getopts :i:b:v:s:hdr opt
do
    case $opt in
    i)
        SET_INNER_IP=$OPTARG
        ;;
    b)
        BRANCH=$OPTARG
        ;;
    v)
        PUPPET_VER=$OPTARG
        ;;
    s)
        START_PUPPET=$OPTARG
        ;;
    d)
        rm_puppet && exit 0 
        ;;
    r)
        restore && exit 0
        ;;
    h)
        help
        ;;
    *)
        echo "Invalid args"
        help
        ;;
    esac
done

os=`uname -s`
if [ $os = 'Linux' ]; then
    check_apt
    check_root
    check_os_version_debian
    backup
    check_aws_debian
    get_myip_debian
    set_apt_source
    init_dns_debian
    init_hostname_debian
    init_sysctl_debian
    set_inner_ip_debian
    rm_old_puppet_debian
    check_puppet_user_debian
    install_pip_debian
    install_systemd_debian
    init_puppet_debian
elif [ $os = 'FreeBSD' ]; then
    check_root
    backup
    check_aws_bsd
    get_ip_bsd
    init_dns_bsd
    init_hostname_bsd
    set_inner_ip_bsd
    check_time_bsd
    install_pkg_bsd
    install_pip_bsd
    init_puppet_bsd
else
    echo "Not support os $os" && exit 1
fi
