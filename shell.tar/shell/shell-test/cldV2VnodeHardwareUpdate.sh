#!/usr/bin/env bash

# 作者: xianwei
# 时间：2019-4-20
# 用途：vnode内核升级


netUpdate()
{
    # R630网卡为X710、X722网卡，需要进行微码升级
    # 判断是否是R630
    [ `which hwtool |wc -l` == 0 ] && { echo "please install hwtool before.Exit." ;return 1; }

    if [ `dmidecode -t system |grep 'PowerEdge R630' |wc -l` == 0 ] ;then
        echo "The machion is not R630 or netcard.Exit."
        return 0
    elif [ `hwtool -m network |grep -E  '710|722'` == 0 ];then
        echo "The machion is R630 but netcard is not x710,x722. Exit."
        return 0
    fi

    # 判断文件是否存在
    [ ! -f intc-lnvgy_fw_nic ] && wget -O intc-lnvgy_fw_nic https://download.lenovo.com/servers/mig/2018/07/12/18976/intc-lnvgy_fw_nic_6.01-3.3x-1.1892.0-c_linux_x86-64.bin

    [ ! -f intc-lnvgy_fw_nic ] && { echo "Download file intc-lnvgy_fw_nic is failed."; return 1; }

    chmod +x intc-lnvgy_fw_nic
    [ -d test0033 ] &&  { echo "mkdir test0033 is exsit.exit!"; return 1; }
    mkdir test0033
    ./intc-lnvgy_fw_nic -x test0033
    cd test0033
    echo yes|./nvmupdate64e &&  { rm -rf test0033 ; echo yes |reboot; } || { echo "not update sucessful!"; return 1; }


}


raidUpdate()
{
    # 升级R630的raid卡
    [ `dmidecode -t system |grep 'PowerEdge R630' |wc -l` == 0 ] && { echo "Not is R630.";return 0; }
    [ `modinfo megaraid_sas | grep -w version |grep 07.705|wc -l ` -gt 0 ] && { echo "Raid Already updated,Dont need update any more." ; return 0; }
    [ ! -f updateMegaraidDriver.sh ] && wget http://hwteam:iwant2download@hw.x.netease.com:8808/raid/updateMegaraidDriver.sh
    [ ! -f updateMegaraidDriver.sh ] &&  { echo "Download file updateMegaraidDriver.sh  is failed."; return 1; }
    bash updateMegaraidDriver.sh  && { yes|reboot;return 0; } || { echo "update Raid failed.Pls check and exit";return 1; }

}


biosUpdate()
{
    # 升级BIOS
    [ ! -f fwhub.py ] &&  wget http://hwteam:iwant2download@hw.x.netease.com:8808/tools/fwhub.py -O fwhub.py
    [ ! -f fwhub.py ] &&  { echo "Download file fwhub.py  is failed."; return 1; }
    [ `python fwhub.py -i 1  |awk '{print $6}' |grep 2.9. |wc -l ` -gt 0 ] && { echo "BIOS Already updated,Dont need update any more." ; \
        python fwhub.py -i 1; return 0; } || python fwhub.py -i 1 -u -y -f
}

kernelUpdate()
{
    # 升级内核为指定版本
    [ `uname -a |grep 3.16.56|wc -l` == 0 ] && apt-get install linux-image-3.16.0-6-amd64=3.16.56-1+deb8u1 \
        && update-grub2 \
        && yes|reboot \
        && return 0
    uname -a
    echo "Dnot need Update kernel."
    return 0
}



#Option deal with
[ -z "$1" ] && echo "$0 -{kbrn}"

#TEMP=`getopt -o ghdu:r: -n 'Error' -- "$@"`
TEMP=`getopt -o rnbk -n 'Error' -- "$@"`
#echo '$TEMP' $TEMP
eval set -- "$TEMP"


while [ ! -z $1 ]
do
    case "$1" in
        -k)
            ## 升级kernel
            kernelUpdate
            shift
            ;;
        -b)
            ## 升级bios
            biosUpdate
            shift
            ;;
        -r)
            ## 升级Raid卡
            raidUpdate
            shift
            ;;
        -n)
            ## 升级网卡
            netUpdate
            shift
            ;;
        *)
            break ;;
    esac
done
exit 0