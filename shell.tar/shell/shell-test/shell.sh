#!/bin/bash

declare -A dic
dic=([term1]="centos" [term2]="debian" [term3]="suse")
#echo ${!dic[*]}                                        #所有key
#echo ${dic[*]}                                         #所有value

read -p "pls input a number:" num


flag=0
for key in `echo ${!dic[*]}`
do
    if [ ${num} == ${key} ];then
        flag=1
        break
    fi
done

if [ ${flag} == 1 ];then
    echo ${dic[${num}]}
else
    echo "not found"

fi



echo




