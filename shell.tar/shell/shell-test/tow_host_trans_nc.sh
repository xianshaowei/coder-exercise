#!/usr/bin/env bash
#用于两个主机之间传输文件的小脚本


port=18371




logger()
{
    local level=$1
    shift
    local msg="$@"

    local color=""
    local msg_datetime=$(date +"[%F %T]")

    case "$level" in
        [Ii][Nn][Ff][Oo]*)
            color=$FGC_GREEN
            ;;
        [Ww][Aa][Rr][Nn]*)
            color=$FGC_YELLOW
            ;;
        [Ee][Rr][Rr]*)
            color=$FGC_RED
            ;;
        *)
            color=$FGC_WHITE
            ;;
    esac
    echo -e $msg_datetime $level "${FGC_START}${color}$msg${FGC_END}" | tee -a $logfile 1>&2
}


check_pkg()
{
    which pv
    if [ $? == 1 ];then
        apt-get install pv -y
        logger CMD " apt-get install pv -y "
    fi
}

allow_fw_port(){
    logger INFO "Before transmission, Allow nc port ${port} "
    if [ $(iptables-save|grep -c -E "${port}") -eq 0 ];then
        logger INFO "Add iptables rule"
        logger CMD "iptables -I INPUT -p tcp --dport ${port} -j ACCEPT"
        iptables -I INPUT -p tcp --dport ${port} -j ACCEPT
        iptables-save|grep "${port}"
    else
        logger Error "Error,already port ${port}"
        iptables-save|grep "dport ${port}"
        exit 1
    fi
}

deny_fw_port(){
    logger INFO "After transmission, Deny nc port ${port}"
    if [ $(iptables-save|grep -c -E "*${port}") -eq 0 ];then
        logger INFO "iptables don't contain allow nc port rule"
    else
        iptables-save|grep "${port}"|while read rule;
        do
            d_rule=$(echo $rule|sed 's/-A INPUT/-D INPUT/')
            logger CMD "iptables ${d_rule}"
            iptables ${d_rule}
        done
        logger INFO "Delete allow nc rule done."
    fi
}

check_pool_exist()
{
    # 检查pool是否存在
    for i in `ls /etc/ceph/ceph*`;do rados lspools --id libvirt -c $i;done |grep -w $1
    if [ $? -eq 0 ];then
        # 存在返回0
        return 0
    else
        return 1
    fi
}


get_cephconf_name()
{
    for i in `ls /etc/ceph/ceph*`
    do
        rados lspools --id libvirt -c $i |grep -w $1
        [ $? -eq 0 ] && return $i
    done
    return None
}

send_rbd()
{
   #发送文件,接收端为客户端,需要后于服务器端运行
   #$2 is poolname,$3 is file_name, $4 is remote_host_ip

   # 判断输入的pool是否存在,不存在就退出
   [ $( check_pool_exist $2 ) -eq 1 ]  && logger Error "Error,$2 is not exist"  && exit 1

    cephconf_name=get_cephconf_name $2

   if [ $( rbd ls -p $2 --id libvirt -c ${cephconf_name} |grep $3|wc -l ) -eq 1 ];then
      #如果img文件存在
       allow_fw_port
       rbd export $2/$3 --id libvirt -c ${cephconf_name} -|pv|nc -q 10 $4 ${port}  && echo "send $2/$3 done"
       deny_fw_port
   else
      logger Error "Error,$2/$3 is not exist"
      exit 1
   fi
}


recv_rbd()
{
   #接收端为服务端,需要先开启接收端口
   #$2 is poolname,$3 is file_name,

   # 判断输入的pool是否存在,不存在就退出
   [ $( check_pool_exist $2 ) -eq 1 ]  && logger Error "Error,$2 is not exist"  && exit 1



   if [  $( rbd ls -p $2  |grep $3|wc -l ) -eq 1 ];then
      #如果文件已经存在,报错并退出
      echo "Error,$1 is already exist!"
      exit 1
   else
      #如果文件不存在,才进行接收文件
      allow_fw_port
      nc -l -vv -s $4 -p ${port}|pv|rbd --image-format 2 import - $2/$3 --id libvirt -c ${cephconf_name}
      deny_fw_port
   fi

}



send_file()
{
   #发送文件
   #$2 is hostip,$3 is file_name,
   if [ $(ls $1  2>/dev/null|wc -l) -eq 1 ];then
      #如果文件存在
       allow_fw_port
       /bin/nc -vv -q 10 $2 ${port} <$1 |pv  && echo "send done"
       deny_fw_port
   else
      echo "Error,$1 is not exist"
      exit 1
   fi
}

recv_file()
{
   #接收端为服务端,需要先开启接收端口
   if [  $(ls $1 2>/dev/null|wc -l ) -eq 1 ];then
      #如果文件已经存在,报错并退出
      echo "Error,$1 is already exist!"
      exit 1
   else
      #如果文件不存在,才进行接收文件
      allow_fw_port
      /bin/nc -l -vv  -p ${port} >$1 |pv  && echo "recv done"
      deny_fw_port
   fi

}



if [ -z "$1" ];then
    echo "Usage: $0 send_file <file_name> <hostnameip>"
    echo "Usage: $0 recv_file <file_name>"
    exit
fi

if [ "$1" == "send_file" ] && [ -z "$2" ] && [ -z "$3" ];then
    echo "Usage: $0 send_file <file_name> <hostnameip>"
    exit
fi

if [ "$1" == "recv_file" ] && [ -z "$2" ];then
    echo "Usage: $0 recv_file <file_name>"
    exit
fi


check_pkg

case "$1" in
    recv_file)
        recv_file $2
        ;;
    send_file)
        send_file $2 $3
        ;;
    *)
        echo "Usage: $0 send_file <file_name> <hostnameip>"
        echo "Usage: $0 recv_file <file_name>"
        ;;
esac