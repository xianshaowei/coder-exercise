#!/usr/bin/env bash


if [ ! -f "/etc/fstab.old" ];then
    cp /etc/fstab /etc/fstab.old
fi

line=$(cat /etc/fstab -n |grep home|awk '{print $1}')
sed -i "${line} s/rw,noatime,nodiratime/rw,inode64,prjquota,noatime,nodiratime/" /etc/fstab

cat /etc/fstab |grep home