#!/bin/bash

ls  /home/xianwei01/vnodeip.txt
if [ $? != 0  ];then
  echo " vnodeip.txt not exist; "
  exit
fi
eth0_ip=`ifconfig eth0|grep -w inet |awk -F'[\:]' '{print $2}'|awk '{print $1}'`
eth2_ip=$(cat /home/xianwei01/vnodeip.txt |grep ${eth0_ip}|awk '{print $3}')
eth3_ip=$(cat /home/xianwei01/vnodeip.txt |grep ${eth0_ip}|awk '{print $4}')
echo ${eth2_ip}
echo ${eth3_ip}



ifconfig eth2  ${eth2_ip} netmask 255.255.254.0 up
ifconfig eth2
ifconfig eth3  ${eth3_ip} netmask 255.255.255.0 up
ifconfig eth3

ping -c 1 -W 2 10.191.206.5
ping -c 1 -W 2 10.191.208.1



