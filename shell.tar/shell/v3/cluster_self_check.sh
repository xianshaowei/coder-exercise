#!/bin/bash
 
# Comments to support chkconfig on Linux

 
# Author : xianwei
# Date   : 2019
# Tel: 13880675749
# 步骤：1. add_cluster. --->  2. add_ns  ---> 3. add_vpc
#      4. 拉subnet,applications进行测试
 
# ======================================
# Script for the xxx Server


# optimize   [] ---> [[]]

#set -o nounset
#set -o errexit
#set -o verbose     #打印执行的代码
#set -o xtrace       #开启调试


logfile=${0}.log


readonly TOKEN='b5lWf%2B42Kv%2BNW4xwb%2FyOrFZHANJdy2Ce757jJAVk%2F7%2BtWMHdzx%2FEZl1d4MWQIPlwd1EMSZRZ0ZSU%0AS7HVYzPduRqZtbsDJvfy%2BXKqx1DOK6j5DGOq3GzBx49NiyI%2Fn9QxOYoolqNlaQ6LtFB35MGvr4Dw%0AHIiR4c3Cc0pV4Qm4EsM%3D%0A'
readonly PROJECT='cld'
readonly REGION='cn-guangzhou'
readonly AZ='gz-gt-1070'
readonly CLUSTER='1071'
readonly CUBE_URL_PRE='http://cld-apisvr1-1070:19090/api/v3/cube'
readonly SYMSVR_IP='10.212.20.12'

logger()
{
    FGC_START="\E[1;"
    FGC_END="\E[00m"
    FGC_YELLOW="33m"
    FGC_RED="31m"
    FGC_GREEN="32m"
    FGC_WHITE="37m"
    local level=$1
    shift
    local msg="$@"

    local color=""
    local msg_datetime=$(date +"[%F %T]")

    case "$level" in
        [Ii][Nn][Ff][Oo]*)
            color=$FGC_GREEN
            ;;
        [Ww][Aa][Rr][Nn]*)
            color=$FGC_YELLOW
            ;;
        [Ee][Rr][Rr]*)
            color=$FGC_RED
            ;;
        *)
            color=$FGC_WHITE
            ;;
    esac

    echo -e "${msg_datetime}" "${level}" "${FGC_START}${color}$msg${FGC_END}" | tee -a "${logfile}" 1>&2

#logger INFO ""logger INFO green strings"
#logger WARRING ""logger INFO yellow strings"
#logger ERROR "logger INFO red strings"
}

curl_get_az()
{
    URL=${CUBE_URL_PRE}/$1
    logger INFO "${URL}"
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -s \
    -X GET \
    "${URL}"
}

curl_get_cluster()
{
    URL=${CUBE_URL_PRE}/$1
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-AZ:${AZ}" \
    -H "X-Auth-Cluster:${CLUSTER}" \
    -s \
    -X GET \
    "${URL}"
}

create_cluster()
{
    URL=${CUBE_URL_PRE}/clusters
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -s \
    -d "\
        {
        \"cluster\":  {
            \"name\": \"${CLUSTER}\",
            \"symUrl\": \"http://${SYMSVR_IP}:42424\",
            \"symVersion\": \"v3\",
            \"passwordKey\": \"eaf8b4cc2ec7fde3fbaa233ee3af2e4b\",
            \"symphonyAdminToken\": \"0cb290b2a9b7d2854e50f6844ac999e4\",
            \"shared\": false,
            \"type\": \"cntr\",
            \"description\": \"cluster ${CLUSTER} in ${AZ} \"
            }
        }
     " \
    -X POST \
    "${URL}"

    sleep 2
}


create_ns()
{
    #创建"test"namespaces
    URL=${CUBE_URL_PRE}/namespaces
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -H "X-Auth-Cluster:${CLUSTER}" \
    -s \
    -d "\
        {
            \"admin\": [
                \"xianwei01\"
                    ],
            \"namespace\": {
                \"name\": \"test\"
            },
            \"public\": true,
            \"members\": [
                \"xianwei01\"
             ],
            \"description\": \"this is namespace test description.\"
        }
     " \
    -X POST \
    "${URL}"

    sleep 2
}

set_quota()
{
    # 创建application前，需要先申请quota
    URL=${CUBE_URL_PRE}/namespaces/test/quotas
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -H "X-Auth-Cluster:${CLUSTER}" \
    -s \
    -d "\
         {
        \"quotas\": {
            \"cpu\": \"10000\",
            \"memory\":\"80Gi\",
            \"pods\": \"1000000\"
            }
         }
     " \
    -X PUT \
    "${URL}"
}
create_subnet()
{
    get_subnets |jq -r .subnets |grep "available" >/dev/null
    if [ $? == 0 ];then
        logger INFO "already have subnets"
        return
    fi
    vpc_uuid=$(get_vpcs |jq -r .vpcs[0].uuid)
    eip=$(get_eips |jq -r .eips[].ip)
    igw_id=$(get_gateways |jq -r .gateways[].uuid)
    cidr_vpc=$(get_vpcs |jq -r .vpcs[0].cidrs[])

    logger INFO "Create subnet: body:","
{
    "subnet": {
        "igwId": "${igw_id}",
        "vpcId": "${vpc_uuid}",
        "name": "vpc001-subnet001",
        "eip": "${eip}",
        "tag": {
            "key1": "val1"
        },
        "cidr": "${cidr_vpc}"
    }
}
     "

    URL=${CUBE_URL_PRE}/subnets
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -H "X-Auth-Cluster:${CLUSTER}" \
    -s \
    -d "\
{
    \"subnet\": {
        \"igwId\": \"${igw_id}\",
        \"vpcId\": \"${vpc_uuid}\",
        \"name\": \"vpc001-subnet001\",
        \"eip\": \"${eip}\",
        \"tag\": {
            \"key1\": \"val1\"
        },
        \"cidr\": \"${cidr_vpc}\"
    }
}
     " \
    -X POST \
    "${URL}"

    sleep 2
}

get_cluster()
{
    curl_get_az clusters
}

get_vpcs()
{
    curl_get_az vpcs
}


get_subnets()
{
    curl_get_az subnets
}

get_ns_quota()
{
    curl_get_cluster test/quotas
}
create_vpc()
{
    if [ `get_vpcs |jq -r .vpcs[0].status` == "available" ];then
        logger INFO "Already have one vpc.Not need to create vpc"
        return 0
    fi
    logger INFO "Create vpc:"
    URL=${CUBE_URL_PRE}/vpcs
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -H "X-Auth-Cluster:${CLUSTER}" \
    -s \
    -d '{"vpc": { "access": "normal","externalBw": 2000,"tag": { "key1": "val1"},"name": "vpc001","shared": false,"description": "the first vpc","type": "cntr","serverCount": 8}}' \
    -X POST \
    "${URL}"
}


create_application()
{
    if [ $(get_applications test |jq -r .applications[].applicationName |wc -l) -ge 3 ];then
        logger INFO "Already more than two applications."
        return
    fi
    rand_num=$RANDOM
    vpc_uuid=$(get_vpcs |jq -r .vpcs[0].uuid)
    subnet_uuid=$(get_subnets |jq -r .subnets[0].uuid)

    logger INFO "Create applications: body:

{
    \"applicationName\": \"test-app${rand_num}\",
    \"application\": {
        \"networking\": {
            \"subnet\": \"${subnet_uuid}\",
            \"vpc\": \"${vpc_uuid}\"
        },
        \"shutdowntime\": 5,
        \"replicas\": 1,
        \"nodeSelector\": {
            \"project\": \"cld\"
        },
        \"oomKillerDisable\": false,
        \"containers\": [
            {
                \"image\": \"dockerhub.nie.netease.com/frosty/sea\",
                \"args\": [],
                \"command\": [
                    \"tailf\",
                    \"/dev/null\"
                ],
                \"cpu\": \"200m\",
                \"memory\": \"256Mi\"
            }
        ]
    }
}
     "

    URL=${CUBE_URL_PRE}/namespaces/test/applications
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -H "X-Auth-Cluster:${CLUSTER}" \
    -s \
    -d "\
{
    \"applicationName\": \"test-app${rand_num}\",
    \"application\": {
        \"networking\": {
            \"subnet\": \"${subnet_uuid}\",
            \"vpc\": \"${vpc_uuid}\"
        },
        \"shutdowntime\": 5,
        \"replicas\": 1,
        \"nodeSelector\": {
            \"project\": \"cld\"
        },
        \"oomKillerDisable\": false,
        \"containers\": [
            {
                \"image\": \"dockerhub.nie.netease.com/frosty/sea\",
                \"args\": [],
                \"command\": [
                    \"tailf\",
                    \"/dev/null\"
                ],
                \"cpu\": \"200m\",
                \"memory\": \"256Mi\"
            }
        ]
    }
}
     " \
    -X POST \
    "${URL}"

    sleep 2
}

get_ns()
{
    curl_get_cluster namespaces

}

get_ns_quotas()
{
    curl_get_cluster quotas
}

get_gateways()
{
    curl_get_az gateways
}

get_eips()
{
    curl_get_az eips
}

get_applications()
{
    URL=${CUBE_URL_PRE}/namespaces/$1/applications
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -H "X-Auth-Cluster:${CLUSTER}" \
    -s \
    -X GET \
    "${URL}"
}

del_appliaction()
{
    URL=${CUBE_URL_PRE}/namespaces/$1/applications/$2
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -H "X-Auth-Cluster:${CLUSTER}" \
    -s \
    -X DELETE \
    "${URL}"
}

del_subnet()
{
    URL=${CUBE_URL_PRE}/subnets/$1
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -H "X-Auth-Cluster:${CLUSTER}" \
    -s \
    -X DELETE \
    "${URL}"
}

del_vpc()
{
    URL=${CUBE_URL_PRE}/vpcs/$1
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -s \
    -X DELETE \
    "${URL}"
}

del_cluster()
{
    [ -z $1 ] && { echo "input cluster uuid";exit 1; }
    URL=${CUBE_URL_PRE}/clusters/$1
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -s \
    -X DELETE \
    "${URL}"
}


del_ns()
{
    [ -z $1 ] && { echo "input one namespaces uuid";exit 1; }
    URL=${CUBE_URL_PRE}/namespaces/$1
    logger INFO ${URL}
    curl -H "Content-Type:application/json"  \
    -H "X-Auth-Token:${TOKEN}" \
    -H "X-Auth-Project:${PROJECT}" \
    -H "X-Auth-Region:${REGION}" \
    -H "X-Auth-Az:${AZ}" \
    -H "X-Auth-Cluster:${CLUSTER}" \
    -s \
    -X DELETE \
    "${URL}"
}

delete_test_applications()
{
   for app in `get_applications test |jq -r .applications[].applicationName`
    do
        logger INFO "app is ${app}"
        if ! echo ${app}|grep test >/dev/null ;then
            logger INFO "${app} not test pod, pls delete it by hand."
            continue
        fi
        if [[  -n "${app}" ]];then
            logger INFO "del_appliaction test ${app}"
            del_appliaction test "${app}"
            local sleeptime=5
            logger INFO "wait ${sleeptime} second"
            sleep ${sleeptime}
        fi
    done
}

delete_subnets_and_applications()
{
    for app in `get_applications test |jq -r .applications[].applicationName`
    do
        logger INFO "app is ${app}"
        if ! echo ${app}|grep test >/dev/null ;then
            logger INFO "${app} not test pod, pls delete it by hand."
            continue
        fi
        if [[  -n "${app}" ]];then
            logger INFO "del_appliaction test ${app}"
            del_appliaction test "${app}"
            local sleeptime=5
            logger INFO "wait ${sleeptime} second"
            sleep ${sleeptime}
        fi
    done


    for subnet in `get_subnets |jq -r .subnets[].uuid`
    do

        subnet_name=$(get_subnets |jq -r .subnets[].name)
        logger INFO "subnet is ${subnet_name}"
        if ! echo ${subnet_name}|grep test >/dev/null ;then
            logger INFO "${subnet_name} not test subnet, pls delete it by hand."
            continue
        fi
        n=30
        logger INFO "pls wait ${n}s!"
        sleep ${n}
        if [[ -n "${subnet}" ]];then
            logger INFO "del_subnet ${subnet}"
            del_subnet ${subnet} && \
            logger INFO "${subnet_name} have been delete."
            local sleeptime=5
            logger INFO "wait ${sleeptime} second"
            sleep ${sleeptime}
        fi
    done
}


dis_usage()
{
logger INFO "操作步骤说明："
cat <<EOF
步骤：1. add_cluster. --->  2. add_ns  ---> 3. add_vpc
     4. 拉subnet,applications进行测试
     5. del 清理环境
Usage: $0 [OPTIONS]
       help                             # help How to use
       list                             # list vpc,subnet and application
       add                              # add vpc, subnet and application
       add_vpc                          # only create vpc
       add_cluster                      # only add one cluster into cube
       sed_quota                        # set quota for namespaces
       del_vpc vpc_uuid                 # delete one vpc
       del_subnet subnet_uuid           # delete one subnet
       del_cluster cluster_uuid         # delete one cluster
       del_ns ns_name                   # delete one namespaces
       del                              # delete subnet and application,Notice: if delete vpc, you need byhand !
EOF
}

test()
{
    #create_vpc
    #get_vpcs
    #get_subnets
    #get_ns
    #get_ns_quotas
    #get_applications test
    #get_gateways |jq -r .gateways[].uuid
    #get_eips |jq -r .eips[].ip

    #del_appliaction test xw-test001
    #del_subnet 1ee433d7-553f-46c7-9ad8-897873520863
    #del_vpc 809f997b-ed7e-423b-befd-4ed0cdd58271
    #get_applications test |jq -r .applications[].applicationName
    #get_subnets |jq -r .subnets[].uuid
    get_vpcs |jq -r .vpcs[0].status
    get_vpcs |jq -r .vpcs[0].cidrs[]
    #get_applications test |jq -r .applications

    #create_vpc
    #delete_subnets_and_applications
    :
    logger INFO "create"
    #create_subnet
    #create_application
    #get_subnets |jq -r .subnets
    #get_applications test |jq -r .applications

    logger INFO "delete"
    #delete_subnets_and_applications

    get_subnets |jq -r .subnets
    get_applications test |jq -r .applications

}



if [  $# -lt 1 ];then
    dis_usage
    exit 1
fi

case $1 in
    add_vpc)
        create_vpc
    ;;
    add_cluster)
        create_cluster
    ;;
    add_ns)
        create_ns
    ;;
    add)
        create_ns
        set_quota
        create_subnet
        create_application test
        create_application test
    ;;
    set_quota)
        set_quota
    ;;
    del_vpc)
        del_vpc $2
    ;;
    del_subnet)
        del_subnet $2
    ;;
    del_cluster)
        del_cluster $2
    ;;
    del_ns)
        del_ns $2
    ;;
    del)
        delete_test_applications
    ;;
    list)
        logger INFO "clusters:"; sleep 2
        get_cluster
        logger INFO "namespaces:"; sleep 1
        get_ns
        #get_ns_quotas
        #get_ns_quota
        logger INFO "vpc:" ;sleep 1
        get_vpcs
        #get_vpcs |jq -r .vpcs
        logger INFO "subnets:" ;sleep 1
        get_subnets
        #get_subnets |jq -r .subnets
        logger INFO "applications:"; sleep 2
        #get_applications test
        get_applications test |jq -r .applications

    ;;
    *)
        dis_usage
    ;;
esac








