mkdir -p $WORKSPACE/go/ && \
mkdir -p $WORKSPACE/src/ && \
export GOPATH=$WORKSPACE
export
go version
repo=${1:-"$gitlabSourceRepoName"}
repo_low=`echo ${repo}|tr ‘[A-Z]’ ‘[a-z]’`
echo ${repo}
tag=${gitlabSourceBranch##*/}
echo ${tag}
echo ${tag}
tag=${tag#*/}
version=$(echo "${tag}")

echo “===================================编译：bash build.sh===================================”
cd $WORKSPACE/src/$gitlabSourceRepoName
bash build.sh
ls -lrt



echo "===================================创建Dockerfile==================================="
cat << eof > Dockerfile
from dockerhub.nie.netease.com/scheduler/debian9_base
COPY lbStatus-controller /usr/bin/
RUN apt-get update && \
    apt-get install -y net-tools
eof

echo "===================================删除原有镜像==================================="
result=$(docker images  |grep whale/${repo_low} |awk  '{print $1":"$2}')
if [ "x$result" != "x" ]; then
    echo “docker rmi $result“
    docker rmi $result
fi

result=$(docker images  |grep ${repo_low} |awk '{print  $3}')
if [ "x$result" != "x" ]; then
    echo “docker rmi $result“
    docker rmi $result
fi

echo "===================================构建镜像==================================="
dockertag=$(echo dockerhub.nie.netease.com/scheduler/${repo_low}:$tag)
pwd
ls
echo “docker build  -t "$dockertag" .”
docker build  -t "$dockertag" .
if [ "x$?" != "x0" ]; then
    echo build failed
    exit 1
fi


echo "===================================上传镜像==================================="
dockertag_whale=`echo ${dockertag}|awk ‘{gsub(“scheduler”, ”whale”);print $0}' `

docker tag   "$dockertag"  “${dockertag_whale}“
docker pull ${dockertag_whale}
if [ "x$?" != "x0" ]; then
    echo “抱歉，build failed”
    content=$(echo "$dockertag_whale 上传失败！！！")
	notify.py  -title "镜像" -content "$content"
    exit 1
else
	echo “恭喜，build successful“
    content=$(echo "$dockertag_whale 上传成功！！！")
	notify.py  -title "镜像" -content "$content"
fi

docker images |grep -w  ${repo_low}


