#!/usr/bin/env bash

#老目录
CONFIGDIR=/etc/cube
#新目录
#CONFIGDIR=/home/cld/conf/cube
VERSION="20181120_release"
DOCKER_HUB="dockerhub.nie.netease.com"
mkdir -p /home/cld/log/cube
docker stop cube-api
docker stop cube-controller
docker stop cube-worker
docker rm cube-api
docker rm cube-controller
docker rm cube-worker
docker run -d --name=cube-api --net=host \
       -v ${CONFIGDIR}/cube.conf:/etc/cube/cube.conf \
       -v /home/cld/log/cube:/var/log/cube \
       $DOCKER_HUB/skyline-cld/cld-api-server:$VERSION \
       --module api --config-file=/etc/cube/cube.conf \
       --logfile /var/log/cube/api.log
docker run -d --name=cube-controller --net=host \
       -v ${CONFIGDIR}/cube.conf:/etc/cube/cube.conf \
       -v /home/cld/log/cube:/var/log/cube \
       $DOCKER_HUB/skyline-cld/cld-api-server:$VERSION \
       --module controller --config-file=/etc/cube/cube.conf \
       --logfile /var/log/cube/controller.log
docker run -d --name=cube-worker --net=host \
       -v ${CONFIGDIR}/cube.conf:/etc/cube/cube.conf \
       -v /home/cld/log/cube:/var/log/cube \
       $DOCKER_HUB/skyline-cld/cld-api-server:$VERSION \
       --module worker --config-file=/etc/cube/cube.conf \
       --logfile /var/log/cube/worker.log
sleep 1
docker ps
