#!/bin/bash
#Author: igi
#Date: 20171011

PATH="$PATH:/usr/local/bin/:/usr/local/sbin/"
URL="http://pub:xCW2quwz6OlRE@pub.x.netease.com:8001/cld/cloudinit"

Sys=`uname`
case "$Sys" in
    Linux)
        iface=`/sbin/ip route | awk '/default/{print $5}'`
        IP="`/sbin/ip addr list $iface | awk '/inet/{split($2,res,"/");print res[1];exit}'`"
        ;;
    FreeBSD)
        IP="`/sbin/ifconfig em0 | awk '/inet/{print $2;exit}'`"
        ;;
    *)
        IP="`/sbin/ifconfig eth0 | awk -F'[: ]+' '/inet/{print $4}'`"
        ;;
esac

count=1
retry=180
while [ $count -le $retry ]
do
    domain="`host -4 $IP`"
    res="$?"
    if [ "$res" -eq 0 ]
    then
        break
    fi

    ((count++))
    sleep 1
done
echo "Sleep for get hostname: $count"

if [ "$res" -eq 0 ]
then
    HOSTNAME="`echo $domain | awk '{sub(".$","",$NF);print $NF}'`"
else
    HOSTNAME=`hostname`
fi

PROJECT="`echo $HOSTNAME | awk -F- '{print $1}'`"
export HOSTNAME PROJECT IP

ComFile="cloudinit-$Sys.sh"
ProFile="$PROJECT.sh"

echo "Download $ComFile and run..."
curl -f $URL/common/$ComFile -o /root/$ComFile && bash /root/$ComFile

echo "Download $ProFile and run..."
curl -f $URL/project/$ProFile -o /root/$ProFile && bash /root/$ProFile