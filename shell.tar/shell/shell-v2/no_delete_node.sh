#!/bin/bash


gid=			#填写gid
hostname_delete=$1

[[ -z ${gid} ]] && exit
if [[ ${gid} -ne  ]];then
   echo "gid is not ${gid}"
   exit
fi

DELETE_URL="http://cld-no1-${gid}:8181/restconf/operations/no-north:delete-host"
GET_URL="http://cld-no1-${gid}:8181/restconf/operations/no-north:get-host"

#get host
#curl -H "Content-Type:application/json" --basic -u admin:admin \
#     -X POST \
#     -d '{"input":{}}' \
#     "${GET_URL}"

#delete host
echo ${hostname_delete}
echo "${DELETE_URL}"
curl -H "Content-Type:application/json" --basic -u admin:admin \
     -X POST \
     -d "{\"input\":{\"id\": \"${hostname_delete}\"}}" \
     "${DELETE_URL}"