#!/bin/bash

# luna repo:
# scheduler_cloud_provider_nks
# scheduler_nks_cluster_ip_controller
set -o nounset
set -o errexit

if [ -z $1 ];then
   exit 1
fi

[[ ! -d /home/xianwei01/_output/bin/download ]] && mkdir -p /home/xianwei01/_output/bin/download

luna_module_name=$1

cat << eof > /home/xianwei01/luna-${luna_module_name}.json
{
    "default": {
        "project": "cld"
    },
    "projects": {
        "cld": {
            "password": "zbeOBYHmd2he12wI",
            "modules": {
                "${luna_module_name}": {
                    "destination": "/home/xianwei01/_output/bin/download",
                    "source":"/home/xianwei01/_output/bin/jenkins"
                }
            }
        }
    }
}
eof

/usr/bin/python -m luna -c /home/xianwei01/luna-${luna_module_name}.json sync --from-s3 -v master ${luna_module_name}
