#!/bin/bash


dest_file=/etc/network/interfaces

#  现在IP举例:10.90.214.11	10.90.216.11
#  新IP举例:  10.90.96.11	10.90.98.11


# 录入掩码和网关
eth0Netmask='255.255.254.0'     # 掩码
eth1Netmask='255.255.254.0'     # 掩码
gatewayIP='10.90.96.1'          # 新IP对应新网关



#判断原始interface文件是否备份
if test ! -f ${dest_file}.OSInstall
then
  cp ${dest_file} ${dest_file}.OSInstall
fi


# 根据原IP修改现在的IP

bond0_ip_suff=$(ifconfig bond0|grep -w inet |awk -F'[\:]' '{print $2}'|awk '{print $1}' |awk -F '[\.]' '{print $NF}')
if [[ $(ifconfig bond0 |grep -w inet |grep 10.90.214|wc -l) -eq 1 ]];then
    # 如果是10.90.214网段，就改成10.90.96.网段
    bond0_ip=10.90.96.${bond0_ip_suff}
    bond1_ip=10.90.98.${bond0_ip_suff}

elif [[ $(ifconfig bond0 |grep -w inet |grep 10.90.215|wc -l) -eq 1 ]];then
    # 如果是10.90.215网段，就改成10.90.97.网段
    bond0_ip=10.90.97.${bond0_ip_suff}
    bond1_ip=10.90.99.${bond0_ip_suff}
else
    exit 1
fi



cat <<EOF >${dest_file}
auto bond0
iface bond0 inet static
address ${bond0_ip}
netmask 255.255.254.0
gateway ${gatewayIP}
slaves eth0 eth2
	bond_mode 802.3ad
	bond_xmit_hash_policy layer2+3
	bond_miimon 100
	bond_updelay 200
	bond_downdelay 200

auto bond1
iface bond1 inet static
address ${bond1_ip}
netmask 255.255.254.0
slaves eth1 eth3
    bond_mode 802.3ad
    bond_xmit_hash_policy layer2+3
    bond_miimon 100
    bond_updelay 200
    bond_downdelay 200
auto lo
iface lo inet loopback
EOF


echo "cat ${dest_file}"
cat ${dest_file}

# 修改/etc/network/interfaces后，需要重启生效
echo "====================================need reboot by hand============================================"
echo "need to reboot to take effect."

