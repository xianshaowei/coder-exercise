#!/bin/bash

# author:xianwei01
# date:20190605
# functions: 用于麒麟座替换后端存储池

#set -x
[ -z $1 ] && { echo "usage: command -p poolname volume-type"; exit 1; }
[ -z $2 ] && { echo "usage: command -p poolname volume-type"; exit 1; }
ceph_acc_id="libvirt"
ceph_conf="/etc/ceph/ceph46.conf"
pool_name=$1
volume_type=$2

# 判断pool是否存在
rados lspools --id ${ceph_acc_id} -c ${ceph_conf} |grep -w ${pool_name}
if [ $? -ne 0 ];then
    echo "Error,pool_name: ${pool_name}  is not exist."
    exit 1
fi

# 判断volume-type是否存在
cinder type-list |grep -w ${volume_type}
if [ $? -ne 0 ];then
    echo "Error,volume_type: ${volume_type}  is not exist."
    exit 1
fi

# 判断ceph.conf是否正确
#echo ${pool_name} |grep phoenix
#if [ $? -eq 0 ];then
#    if [ `echo ${ceph_conf} |grep ceph46.conf|wc -l` -ne 1   ];then
#        echo "ceph_conf is error."
#        exit 1
#    fi
#fi


while read tmplate_name volume_size
do
   echo ${volume_type} |grep sas
   if [ $? -eq 0 ];then
        volume_name_suff='_sas_using'
   else
        volume_name_suff='_ssd_using'
   fi
   # 创建镜像卷
   volume_name=`echo ${tmplate_name}|sed 's/cld_//g' |sed 's/.qcow2_import_template//g'`
   echo "cinder create --volume-type ${volume_type} --name ${volume_name}${volume_name_suff} ${volume_size}"
   cinder create --volume-type ${volume_type} --name ${volume_name}${volume_name_suff} ${volume_size} && \
   [ `cinder list |grep ${volume_name}${volume_name_suff} |wc -l` -ne 1  ] && { echo "Error,cinder list";exit 1;}
   volume_id=`cinder list |grep ${volume_name}${volume_name_suff}  |awk '{print $2}'` && \

   # 将镜像模版数据复制导镜像卷
   echo "rbd mv --id ${ceph_acc_id} -c ${ceph_conf}  ${pool_name}/volume-${volume_id}  ${pool_name}/volume-${volume_id}.bak" && \
   rbd mv --id ${ceph_acc_id} -c ${ceph_conf}  ${pool_name}/volume-${volume_id}  ${pool_name}/volume-${volume_id}.bak && \
   echo "rbd cp --id ${ceph_acc_id} -c ${ceph_conf}  ${pool_name}/${tmplate_name}  ${pool_name}/volume-${volume_id}"
   rbd cp --id ${ceph_acc_id} -c ${ceph_conf}  ${pool_name}/${tmplate_name}  ${pool_name}/volume-${volume_id} && \
   cinder set-bootable ${volume_id} true

    # 利用镜像卷创建快照
    snapshot_name="${volume_name}${volume_name_suff}"
    echo "cinder snapshot-create --name ${snapshot_name} ${volume_id}"
    cinder snapshot-create --name ${volume_name}${volume_name_suff} ${volume_id} && \

    cinder snapshot-list |grep ${volume_name}
done <image_size.txt

#set +x